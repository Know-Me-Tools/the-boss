use std::collections::HashMap;
use std::sync::Arc;

use chrono::Utc;
use sqlx::SqlitePool;
use tracing::{debug, info};

use mempalace_core::{Drawer, DrawerInput, MempalaceError, Result, SearchFilter, SearchResult};

use crate::embedder::{blob_to_vec, cosine_similarity, vec_to_blob, Embedder};
use crate::reranker::{RerankCandidate, Reranker};

// ── Pool helper ───────────────────────────────────────────────────────────────

pub async fn open_pool(palace_path: &str) -> Result<SqlitePool> {
    std::fs::create_dir_all(palace_path)?;
    let db_path = format!("{palace_path}/palace.sqlite3");
    let url = format!("sqlite://{db_path}?mode=rwc");
    let pool = SqlitePool::connect(&url).await?;
    sqlx::migrate!("./migrations").run(&pool).await?;
    Ok(pool)
}

// ── DrawerStore ───────────────────────────────────────────────────────────────

#[derive(Clone)]
pub struct DrawerStore {
    pool:     SqlitePool,
    embedder: Arc<dyn Embedder>,
    reranker: Arc<dyn Reranker>,
    /// Stage-1 over-fetch factor (stage1_limit = limit × factor).
    candidate_factor: usize,
}

impl DrawerStore {
    pub fn new(
        pool:             SqlitePool,
        embedder:         Arc<dyn Embedder>,
        reranker:         Arc<dyn Reranker>,
        candidate_factor: usize,
    ) -> Self {
        Self { pool, embedder, reranker, candidate_factor }
    }

    // ── Write ─────────────────────────────────────────────────────────────────

    pub async fn add(&self, input: DrawerInput) -> Result<String> {
        let emb  = self.embedder.embed_one(&input.content).await?;
        let blob = vec_to_blob(&emb);
        let id   = make_drawer_id(&input.wing, &input.room, &input.source_file, input.chunk_index);
        let now  = Utc::now().to_rfc3339();

        sqlx::query!(
            r#"INSERT OR IGNORE INTO drawers
               (id, wing, room, hall, content, source_file, chunk_index, added_by, filed_at, importance, embedding)
               VALUES (?,?,?,?,?,?,?,?,?,?,?)"#,
            id, input.wing, input.room, input.hall, input.content,
            input.source_file, input.chunk_index, input.added_by, now, input.importance, blob,
        ).execute(&self.pool).await?;

        debug!("Stored drawer {id} → {}/{}", input.wing, input.room);
        Ok(id)
    }

    pub async fn file_already_mined(&self, source_file: &str) -> Result<bool> {
        let n: i64 = sqlx::query_scalar!(
            "SELECT COUNT(*) FROM drawers WHERE source_file = ?", source_file
        ).fetch_one(&self.pool).await?;
        Ok(n > 0)
    }

    pub async fn delete(&self, id: &str) -> Result<bool> {
        let n = sqlx::query!("DELETE FROM drawers WHERE id = ?", id)
            .execute(&self.pool).await?.rows_affected();
        Ok(n > 0)
    }

    // ── Read / list ───────────────────────────────────────────────────────────

    pub async fn count(&self) -> Result<usize> {
        let n: i64 = sqlx::query_scalar!("SELECT COUNT(*) FROM drawers")
            .fetch_one(&self.pool).await?;
        Ok(n as usize)
    }

    pub async fn get_filtered(&self, filter: &SearchFilter, limit: usize) -> Result<Vec<Drawer>> {
        // Four cases to keep sqlx happy with its static-query macros.
        let rows: Vec<DrawerRow> = match (&filter.wing, &filter.room) {
            (Some(w), Some(r)) => sqlx::query_as!(DrawerRow,
                r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance
                   FROM drawers WHERE wing=? AND room=? ORDER BY importance DESC LIMIT ?"#, w,r,limit as i64
            ).fetch_all(&self.pool).await?,
            (Some(w), None) => sqlx::query_as!(DrawerRow,
                r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance
                   FROM drawers WHERE wing=? ORDER BY importance DESC LIMIT ?"#, w, limit as i64
            ).fetch_all(&self.pool).await?,
            (None, Some(r)) => sqlx::query_as!(DrawerRow,
                r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance
                   FROM drawers WHERE room=? ORDER BY importance DESC LIMIT ?"#, r, limit as i64
            ).fetch_all(&self.pool).await?,
            (None, None) => sqlx::query_as!(DrawerRow,
                r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance
                   FROM drawers ORDER BY importance DESC LIMIT ?"#, limit as i64
            ).fetch_all(&self.pool).await?,
        };
        rows.into_iter().map(DrawerRow::into_drawer).collect()
    }

    pub async fn get_all_meta(&self) -> Result<Vec<DrawerMeta>> {
        sqlx::query_as!(DrawerMetaRow,
            "SELECT id,wing,room,hall,source_file,importance,filed_at FROM drawers"
        ).fetch_all(&self.pool).await?
            .into_iter().map(|r| Ok(r.into_meta()))
            .collect()
    }

    // ── Two-stage search ──────────────────────────────────────────────────────

    /// Stage 1: embed query + cosine similarity over filtered candidates.
    /// Stage 2: apply reranker to trim to `limit`.
    pub async fn search(
        &self,
        query:  &str,
        filter: &SearchFilter,
        limit:  usize,
    ) -> Result<Vec<SearchResult>> {
        let stage1_limit = limit.saturating_mul(self.candidate_factor).max(limit);
        let query_emb = self.embedder.embed_one(query).await?;

        // Load embeddings for filtered candidates.
        let rows: Vec<EmbeddingRow> = match (&filter.wing, &filter.room) {
            (Some(w), Some(r)) => sqlx::query_as!(EmbeddingRow,
                r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance,embedding
                   FROM drawers WHERE wing=? AND room=? AND embedding IS NOT NULL"#, w, r
            ).fetch_all(&self.pool).await?,
            (Some(w), None) => sqlx::query_as!(EmbeddingRow,
                r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance,embedding
                   FROM drawers WHERE wing=? AND embedding IS NOT NULL"#, w
            ).fetch_all(&self.pool).await?,
            (None, Some(r)) => sqlx::query_as!(EmbeddingRow,
                r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance,embedding
                   FROM drawers WHERE room=? AND embedding IS NOT NULL"#, r
            ).fetch_all(&self.pool).await?,
            (None, None) => sqlx::query_as!(EmbeddingRow,
                r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance,embedding
                   FROM drawers WHERE embedding IS NOT NULL"#
            ).fetch_all(&self.pool).await?,
        };

        info!("Search stage-1: scoring {} candidates (reranker={})",
              rows.len(), self.reranker.name());

        // Score stage-1, keep top-(stage1_limit).
        let mut scored: Vec<(f32, EmbeddingRow)> = rows.into_iter().filter_map(|row| {
            let blob = row.embedding.as_deref()?;
            let emb  = blob_to_vec(blob);
            let sim  = cosine_similarity(&query_emb, &emb);
            Some((sim, row))
        }).collect();
        scored.sort_unstable_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
        scored.truncate(stage1_limit);

        // Build candidates for stage-2.
        let candidates: Vec<RerankCandidate> = scored.iter().map(|(sim, row)| RerankCandidate {
            id:            row.id.clone(),
            text:          row.content.clone(),
            initial_score: *sim,
        }).collect();

        // Stage-2 rerank.
        let reranked = self.reranker.rerank(query, candidates, limit).await?;

        // Build a lookup map from stage-1 so we can attach full Drawer data.
        let row_map: HashMap<String, EmbeddingRow> = scored.into_iter()
            .map(|(_, row)| (row.id.clone(), row))
            .collect();

        reranked.into_iter().filter_map(|rr| {
            let row = row_map.get(&rr.id)?.clone();
            let drawer = row.into_drawer().ok()?;
            Some(SearchResult { drawer, score: rr.score, rank: rr.rank })
        }).collect::<Vec<_>>().pipe_ok()
    }

    pub async fn check_duplicate(&self, content: &str, threshold: f32) -> Result<Option<(String, f32)>> {
        let qemb = self.embedder.embed_one(content).await?;
        let rows: Vec<EmbeddingRow> = sqlx::query_as!(EmbeddingRow,
            r#"SELECT id,wing,room,hall,content,source_file,chunk_index,added_by,filed_at,importance,embedding
               FROM drawers WHERE embedding IS NOT NULL LIMIT 2000"#
        ).fetch_all(&self.pool).await?;

        Ok(rows.iter().filter_map(|row| {
            let emb = blob_to_vec(row.embedding.as_deref()?);
            let sim = cosine_similarity(&qemb, &emb);
            if sim >= threshold { Some((row.id.clone(), sim)) } else { None }
        }).max_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal)))
    }

    pub async fn wing_room_counts(&self) -> Result<HashMap<String, HashMap<String, usize>>> {
        let rows = sqlx::query!(
            "SELECT wing, room, COUNT(*) as cnt FROM drawers GROUP BY wing, room"
        ).fetch_all(&self.pool).await?;
        let mut map: HashMap<String, HashMap<String, usize>> = HashMap::new();
        for r in rows { *map.entry(r.wing).or_default().entry(r.room).or_default() += r.cnt as usize; }
        Ok(map)
    }
}

// ── Helper trait for collecting Results ───────────────────────────────────────
trait PipeOk<T> { fn pipe_ok(self) -> Result<T>; }
impl<T> PipeOk<Vec<T>> for Vec<T> { fn pipe_ok(self) -> Result<Vec<T>> { Ok(self) } }

// ── Row structs ───────────────────────────────────────────────────────────────

#[derive(sqlx::FromRow, Clone)]
struct DrawerRow {
    id: String, wing: String, room: String, hall: String, content: String,
    source_file: String, chunk_index: i64, added_by: String, filed_at: String, importance: f64,
}
impl DrawerRow {
    fn into_drawer(self) -> Result<Drawer> {
        use chrono::DateTime;
        let filed_at = DateTime::parse_from_rfc3339(&self.filed_at)
            .map(|d| d.with_timezone(&Utc)).unwrap_or_else(|_| Utc::now());
        Ok(Drawer { id: self.id, wing: self.wing, room: self.room, hall: self.hall,
                    content: self.content, source_file: self.source_file,
                    chunk_index: self.chunk_index, added_by: self.added_by,
                    filed_at, importance: self.importance as f32 })
    }
}

#[derive(sqlx::FromRow, Clone)]
struct EmbeddingRow {
    id: String, wing: String, room: String, hall: String, content: String,
    source_file: String, chunk_index: i64, added_by: String, filed_at: String,
    importance: f64, embedding: Option<Vec<u8>>,
}
impl EmbeddingRow {
    fn into_drawer(self) -> Result<Drawer> {
        use chrono::DateTime;
        let filed_at = DateTime::parse_from_rfc3339(&self.filed_at)
            .map(|d| d.with_timezone(&Utc)).unwrap_or_else(|_| Utc::now());
        Ok(Drawer { id: self.id, wing: self.wing, room: self.room, hall: self.hall,
                    content: self.content, source_file: self.source_file,
                    chunk_index: self.chunk_index, added_by: self.added_by,
                    filed_at, importance: self.importance as f32 })
    }
}

#[derive(sqlx::FromRow)]
struct DrawerMetaRow {
    id: String, wing: String, room: String, hall: String,
    source_file: String, importance: f64, filed_at: String,
}
impl DrawerMetaRow {
    fn into_meta(self) -> DrawerMeta {
        DrawerMeta { id: self.id, wing: self.wing, room: self.room, hall: self.hall,
                     source_file: self.source_file, importance: self.importance as f32,
                     filed_at: self.filed_at }
    }
}

#[derive(Debug, Clone)]
pub struct DrawerMeta {
    pub id: String, pub wing: String, pub room: String, pub hall: String,
    pub source_file: String, pub importance: f32, pub filed_at: String,
}

fn make_drawer_id(wing: &str, room: &str, source_file: &str, chunk_index: i64) -> String {
    let h = blake3::hash(format!("{source_file}{chunk_index}").as_bytes());
    format!("drawer_{wing}_{room}_{}", &h.to_hex()[..16])
}
