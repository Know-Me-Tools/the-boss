use std::sync::Arc;
use async_trait::async_trait;
use tokio::task;
use tracing::{debug, info};
use mempalace_core::{MempalaceConfig, MempalaceError, Result, EMBEDDING_DIM};

#[async_trait]
pub trait Embedder: Send + Sync {
    async fn embed(&self, texts: &[&str]) -> Result<Vec<Vec<f32>>>;
    async fn embed_one(&self, text: &str) -> Result<Vec<f32>> {
        self.embed(&[text]).await?.into_iter().next()
            .ok_or_else(|| MempalaceError::embedding("embedder returned empty"))
    }
    fn dim(&self) -> usize;
}

pub fn build_embedder(cfg: &MempalaceConfig) -> Result<Arc<dyn Embedder>> {
    if let Some(url) = &cfg.embedding_api_url {
        info!("Remote embedder: {url}");
        Ok(Arc::new(RemoteEmbedder::new(url.clone(), cfg.embedding_api_key.clone(), cfg.embedding_model.clone())))
    } else {
        info!("Local fastembed ({})", cfg.embedding_model);
        Ok(Arc::new(LocalEmbedder::new()?))
    }
}

// ── Local (fastembed / ONNX) ──────────────────────────────────────────────────
pub struct LocalEmbedder {
    inner: Arc<std::sync::Mutex<fastembed::TextEmbedding>>,
}
impl LocalEmbedder {
    pub fn new() -> Result<Self> {
        use fastembed::{EmbeddingModel, InitOptions, TextEmbedding};
        let model = TextEmbedding::try_new(
            InitOptions::new(EmbeddingModel::AllMiniLML6V2).with_show_download_progress(true),
        ).map_err(|e| MempalaceError::embedding(format!("fastembed init: {e}")))?;
        Ok(Self { inner: Arc::new(std::sync::Mutex::new(model)) })
    }
}
#[async_trait]
impl Embedder for LocalEmbedder {
    async fn embed(&self, texts: &[&str]) -> Result<Vec<Vec<f32>>> {
        let owned: Vec<String> = texts.iter().map(|s| s.to_string()).collect();
        let inner = Arc::clone(&self.inner);
        task::spawn_blocking(move || {
            let g = inner.lock().map_err(|_| MempalaceError::embedding("lock poisoned"))?;
            g.embed(owned.iter().map(|s| s.as_str()).collect(), None)
                .map_err(|e| MempalaceError::embedding(format!("fastembed: {e}")))
        }).await.map_err(|e| MempalaceError::embedding(format!("task panic: {e}")))?
    }
    fn dim(&self) -> usize { EMBEDDING_DIM }
}

// ── Remote (OpenAI-compatible /v1/embeddings) ─────────────────────────────────
pub struct RemoteEmbedder { client: reqwest::Client, url: String, api_key: Option<String>, model: String }
impl RemoteEmbedder {
    pub fn new(url: String, api_key: Option<String>, model: String) -> Self {
        Self { client: reqwest::Client::new(), url, api_key, model }
    }
}
#[async_trait]
impl Embedder for RemoteEmbedder {
    async fn embed(&self, texts: &[&str]) -> Result<Vec<Vec<f32>>> {
        let body = serde_json::json!({ "model": self.model, "input": texts });
        let mut req = self.client.post(&self.url).json(&body);
        if let Some(k) = &self.api_key { req = req.bearer_auth(k); }
        let resp: serde_json::Value = req.send().await
            .map_err(|e| MempalaceError::embedding(format!("http: {e}")))?
            .json().await
            .map_err(|e| MempalaceError::embedding(format!("json: {e}")))?;
        resp["data"].as_array()
            .ok_or_else(|| MempalaceError::embedding("missing data"))?
            .iter().map(|item| {
                item["embedding"].as_array()
                    .ok_or_else(|| MempalaceError::embedding("missing embedding"))
                    .map(|a| a.iter().map(|v| v.as_f64().unwrap_or(0.0) as f32).collect())
            }).collect()
    }
    fn dim(&self) -> usize { EMBEDDING_DIM }
}

// ── Vector utilities ──────────────────────────────────────────────────────────
pub fn vec_to_blob(v: &[f32]) -> Vec<u8> { v.iter().flat_map(|f| f.to_le_bytes()).collect() }
pub fn blob_to_vec(b: &[u8]) -> Vec<f32> {
    b.chunks_exact(4).map(|c| f32::from_le_bytes(c.try_into().unwrap())).collect()
}
pub fn cosine_similarity(a: &[f32], b: &[f32]) -> f32 {
    debug_assert_eq!(a.len(), b.len());
    let dot: f32 = a.iter().zip(b).map(|(x, y)| x * y).sum();
    let ma: f32 = a.iter().map(|x| x*x).sum::<f32>().sqrt();
    let mb: f32 = b.iter().map(|x| x*x).sum::<f32>().sqrt();
    if ma == 0.0 || mb == 0.0 { 0.0 } else { dot / (ma * mb) }
}
