use std::collections::HashMap;
use chrono::{Local, Utc};
use sqlx::SqlitePool;
use mempalace_core::{MempalaceError, ResolvedTriple, Result, TripleInput};
use serde::{Deserialize, Serialize};

pub async fn open_kg_pool(db_path: &str) -> Result<SqlitePool> {
    if let Some(p) = std::path::Path::new(db_path).parent() { std::fs::create_dir_all(p)?; }
    let pool = SqlitePool::connect(&format!("sqlite://{db_path}?mode=rwc")).await?;
    sqlx::migrate!("./migrations").run(&pool).await?;
    Ok(pool)
}

#[derive(Clone)]
pub struct KnowledgeGraph { pool: SqlitePool }

impl KnowledgeGraph {
    pub fn new(pool: SqlitePool) -> Self { Self { pool } }

    pub async fn add_entity(&self, name: &str, etype: &str, props: Option<&HashMap<String, serde_json::Value>>) -> Result<String> {
        let id = eid(name);
        let p  = serde_json::to_string(&props.unwrap_or(&HashMap::new()))
            .map_err(|e| MempalaceError::Json(e))?;
        sqlx::query!("INSERT OR REPLACE INTO kg_entities (id,name,type,properties,created_at) VALUES(?,?,?,?,?)",
            id, name, etype, p, Utc::now().to_rfc3339()
        ).execute(&self.pool).await?;
        Ok(id)
    }

    pub async fn add_triple(&self, inp: TripleInput) -> Result<String> {
        let sid = eid(&inp.subject); let oid = eid(&inp.object);
        let pred = norm_pred(&inp.predicate);
        let now  = Utc::now().to_rfc3339();
        self.ensure_entity(&sid, &inp.subject).await?;
        self.ensure_entity(&oid, &inp.object).await?;
        if let Some(ex) = sqlx::query_scalar!(
            "SELECT id FROM kg_triples WHERE subject=? AND predicate=? AND object=? AND valid_to IS NULL",
            sid, pred, oid
        ).fetch_optional(&self.pool).await? { return Ok(ex); }
        let tid = make_tid(&sid, &pred, &oid, &inp.valid_from);
        sqlx::query!(
            "INSERT INTO kg_triples(id,subject,predicate,object,valid_from,valid_to,confidence,source_closet,source_file,extracted_at) VALUES(?,?,?,?,?,?,?,?,?,?)",
            tid, sid, pred, oid, inp.valid_from, inp.valid_to, inp.confidence, inp.source_closet, inp.source_file, now
        ).execute(&self.pool).await?;
        Ok(tid)
    }

    pub async fn invalidate(&self, sub: &str, pred: &str, obj: &str, ended: Option<&str>) -> Result<()> {
        let sid = eid(sub); let oid = eid(obj); let p = norm_pred(pred);
        let ended = ended.map(str::to_string).unwrap_or_else(|| Local::now().date_naive().to_string());
        sqlx::query!("UPDATE kg_triples SET valid_to=? WHERE subject=? AND predicate=? AND object=? AND valid_to IS NULL",
            ended, sid, p, oid
        ).execute(&self.pool).await?;
        Ok(())
    }

    pub async fn query_entity(&self, name: &str, as_of: Option<&str>, direction: &str) -> Result<Vec<ResolvedTriple>> {
        let eid_v = eid(name);
        let mut out = Vec::new();
        if matches!(direction, "outgoing" | "both") {
            for r in self.outgoing(&eid_v, as_of).await? {
                out.push(ResolvedTriple { direction: "outgoing".into(), subject: name.into(),
                    predicate: r.predicate, object: r.obj_name,
                    valid_from: r.valid_from, valid_to: r.valid_to.clone(),
                    confidence: r.confidence, source_closet: r.source_closet,
                    current: r.valid_to.is_none() });
            }
        }
        if matches!(direction, "incoming" | "both") {
            for r in self.incoming(&eid_v, as_of).await? {
                out.push(ResolvedTriple { direction: "incoming".into(), subject: r.sub_name,
                    predicate: r.predicate, object: name.into(),
                    valid_from: r.valid_from, valid_to: r.valid_to.clone(),
                    confidence: r.confidence, source_closet: r.source_closet,
                    current: r.valid_to.is_none() });
            }
        }
        Ok(out)
    }

    pub async fn timeline(&self, entity: Option<&str>) -> Result<Vec<ResolvedTriple>> {
        let rows = match entity {
            Some(n) => { let e = eid(n);
                sqlx::query!("SELECT t.predicate,t.valid_from,t.valid_to,t.confidence,s.name as sub_name,o.name as obj_name \
                              FROM kg_triples t JOIN kg_entities s ON t.subject=s.id JOIN kg_entities o ON t.object=o.id \
                              WHERE (t.subject=? OR t.object=?) ORDER BY t.valid_from ASC NULLS LAST LIMIT 100", e,e)
                    .fetch_all(&self.pool).await?
                    .into_iter().map(|r| ResolvedTriple { direction:"outgoing".into(), subject:r.sub_name,
                        predicate:r.predicate, object:r.obj_name, valid_from:r.valid_from, valid_to:r.valid_to.clone(),
                        confidence:r.confidence, source_closet:None, current:r.valid_to.is_none() }).collect()
            }
            None => sqlx::query!("SELECT t.predicate,t.valid_from,t.valid_to,t.confidence,s.name as sub_name,o.name as obj_name \
                                  FROM kg_triples t JOIN kg_entities s ON t.subject=s.id JOIN kg_entities o ON t.object=o.id \
                                  ORDER BY t.valid_from ASC NULLS LAST LIMIT 100")
                    .fetch_all(&self.pool).await?
                    .into_iter().map(|r| ResolvedTriple { direction:"outgoing".into(), subject:r.sub_name,
                        predicate:r.predicate, object:r.obj_name, valid_from:r.valid_from, valid_to:r.valid_to.clone(),
                        confidence:r.confidence, source_closet:None, current:r.valid_to.is_none() }).collect(),
        };
        Ok(rows)
    }

    pub async fn stats(&self) -> Result<KgStats> {
        let entities: i64 = sqlx::query_scalar!("SELECT COUNT(*) FROM kg_entities").fetch_one(&self.pool).await?;
        let triples:  i64 = sqlx::query_scalar!("SELECT COUNT(*) FROM kg_triples").fetch_one(&self.pool).await?;
        let current:  i64 = sqlx::query_scalar!("SELECT COUNT(*) FROM kg_triples WHERE valid_to IS NULL").fetch_one(&self.pool).await?;
        let predicates: Vec<String> = sqlx::query_scalar!("SELECT DISTINCT predicate FROM kg_triples ORDER BY predicate").fetch_all(&self.pool).await?;
        Ok(KgStats { entities: entities as usize, triples: triples as usize,
                     current_facts: current as usize, expired_facts: (triples-current) as usize,
                     relationship_types: predicates })
    }

    async fn ensure_entity(&self, id: &str, name: &str) -> Result<()> {
        sqlx::query!("INSERT OR IGNORE INTO kg_entities(id,name,created_at) VALUES(?,?,?)",
            id, name, Utc::now().to_rfc3339()
        ).execute(&self.pool).await?;
        Ok(())
    }

    async fn outgoing(&self, eid_v: &str, as_of: Option<&str>) -> Result<Vec<OutRow>> {
        Ok(match as_of {
            Some(d) => sqlx::query_as!(OutRow,
                "SELECT t.predicate,t.valid_from,t.valid_to,t.confidence,t.source_closet,e.name as obj_name \
                 FROM kg_triples t JOIN kg_entities e ON t.object=e.id WHERE t.subject=? \
                 AND (t.valid_from IS NULL OR t.valid_from<=?) AND (t.valid_to IS NULL OR t.valid_to>=?)",
                eid_v, d, d).fetch_all(&self.pool).await?,
            None => sqlx::query_as!(OutRow,
                "SELECT t.predicate,t.valid_from,t.valid_to,t.confidence,t.source_closet,e.name as obj_name \
                 FROM kg_triples t JOIN kg_entities e ON t.object=e.id WHERE t.subject=?", eid_v)
                .fetch_all(&self.pool).await?,
        })
    }
    async fn incoming(&self, eid_v: &str, as_of: Option<&str>) -> Result<Vec<InRow>> {
        Ok(match as_of {
            Some(d) => sqlx::query_as!(InRow,
                "SELECT t.predicate,t.valid_from,t.valid_to,t.confidence,t.source_closet,e.name as sub_name \
                 FROM kg_triples t JOIN kg_entities e ON t.subject=e.id WHERE t.object=? \
                 AND (t.valid_from IS NULL OR t.valid_from<=?) AND (t.valid_to IS NULL OR t.valid_to>=?)",
                eid_v, d, d).fetch_all(&self.pool).await?,
            None => sqlx::query_as!(InRow,
                "SELECT t.predicate,t.valid_from,t.valid_to,t.confidence,t.source_closet,e.name as sub_name \
                 FROM kg_triples t JOIN kg_entities e ON t.subject=e.id WHERE t.object=?", eid_v)
                .fetch_all(&self.pool).await?,
        })
    }
}

#[derive(sqlx::FromRow)] struct OutRow { predicate:String, valid_from:Option<String>, valid_to:Option<String>, confidence:f64, source_closet:Option<String>, obj_name:String }
#[derive(sqlx::FromRow)] struct InRow  { predicate:String, valid_from:Option<String>, valid_to:Option<String>, confidence:f64, source_closet:Option<String>, sub_name:String }

#[derive(Debug,Clone,Serialize,Deserialize)]
pub struct KgStats { pub entities:usize, pub triples:usize, pub current_facts:usize, pub expired_facts:usize, pub relationship_types:Vec<String> }

fn eid(n: &str) -> String { n.to_lowercase().replace(' ','_').replace('\'', "") }
fn norm_pred(p: &str) -> String { p.to_lowercase().replace(' ','_') }
fn make_tid(s: &str, p: &str, o: &str, vf: &Option<String>) -> String {
    let h = blake3::hash(format!("{s}{p}{o}{}{}", vf.as_deref().unwrap_or(""), Utc::now().timestamp_nanos_opt().unwrap_or(0)).as_bytes());
    format!("t_{s}_{p}_{o}_{}", &h.to_hex()[..8])
}
