pub mod drawer_store;
pub mod embedder;
pub mod knowledge_graph;
pub mod reranker;

pub use drawer_store::{open_pool, DrawerMeta, DrawerStore};
pub use embedder::{blob_to_vec, build_embedder, cosine_similarity, vec_to_blob, Embedder};
pub use knowledge_graph::{open_kg_pool, KgStats, KnowledgeGraph};
pub use reranker::{
    build_reranker, CosineSimilarityReranker, CrossEncoderReranker, RerankCandidate,
    RerankResult, Reranker, RrfReranker, WeightedReranker,
};

use std::sync::Arc;
use mempalace_core::{MempalaceConfig, Result};

/// Convenience: open all stores from one config.
pub struct Palace {
    pub drawers: DrawerStore,
    pub kg:      KnowledgeGraph,
    pub config:  Arc<MempalaceConfig>,
}

impl Palace {
    pub async fn open(config: MempalaceConfig) -> Result<Self> {
        let palace_path = config.palace_path.to_string_lossy().into_owned();
        let kg_path     = mempalace_core::default_kg_path().to_string_lossy().into_owned();

        let embedder  = build_embedder(&config)?;
        let reranker  = build_reranker(&config);
        let pool      = open_pool(&palace_path).await?;
        let kg_pool   = open_kg_pool(&kg_path).await?;
        let factor    = config.candidate_factor;

        Ok(Self {
            drawers: DrawerStore::new(pool, Arc::from(embedder), reranker, factor),
            kg:      KnowledgeGraph::new(kg_pool),
            config:  Arc::new(config),
        })
    }
}
