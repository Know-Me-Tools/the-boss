//! Reranker abstraction — second-stage retrieval scoring.
//!
//! After the first-stage embedding search returns `N` candidates (where
//! `N = limit × candidate_factor`), a [`Reranker`] scores them and trims the
//! list to the final `limit`.
//!
//! # Provided implementations
//!
//! | Type | Description |
//! |------|-------------|
//! | [`CosineSimilarityReranker`] | Default. Sorts by stage-1 score; zero extra latency. |
//! | [`CrossEncoderReranker`]    | Calls `/v1/rerank` (Cohere, Jina, Mixedbread, liter-llm). |
//! | [`RrfReranker`]             | Reciprocal Rank Fusion over two result sets. |
//! | [`WeightedReranker`]        | Linear blend of two rerankers. |
//!
//! Build the right implementation from config with [`build_reranker`].

use std::sync::Arc;
use async_trait::async_trait;
use tracing::{debug, info};
use mempalace_core::{MempalaceConfig, MempalaceError, RerankerConfig, Result};

// ── Public types ──────────────────────────────────────────────────────────────

/// A single candidate produced by first-stage retrieval.
#[derive(Debug, Clone)]
pub struct RerankCandidate {
    /// Drawer ID (matches `Drawer::id`).
    pub id: String,
    /// The verbatim text of the drawer.
    pub text: String,
    /// Cosine similarity score from the embedding stage (0.0 – 1.0).
    pub initial_score: f32,
}

/// One item in the reranker's output — maps back to a `Drawer` by `id`.
#[derive(Debug, Clone)]
pub struct RerankResult {
    pub id: String,
    /// Final relevance score after reranking.
    pub score: f32,
    /// 1-based rank (1 = most relevant).
    pub rank: usize,
}

// ── Trait ─────────────────────────────────────────────────────────────────────

/// Trait for all reranking strategies.
///
/// Implementations receive the search query and an already-scored candidate
/// list from stage 1, and return a trimmed, re-ordered result list.
#[async_trait]
pub trait Reranker: Send + Sync {
    /// Rerank `candidates` for `query`, returning at most `top_k` results.
    async fn rerank(
        &self,
        query: &str,
        candidates: Vec<RerankCandidate>,
        top_k: usize,
    ) -> Result<Vec<RerankResult>>;

    /// Human-readable name used in logging and status output.
    fn name(&self) -> &str;
}

// ── Factory ───────────────────────────────────────────────────────────────────

/// Build the appropriate [`Reranker`] from a [`MempalaceConfig`].
pub fn build_reranker(cfg: &MempalaceConfig) -> Arc<dyn Reranker> {
    build_from_config(&cfg.reranker)
}

fn build_from_config(rc: &RerankerConfig) -> Arc<dyn Reranker> {
    match rc {
        RerankerConfig::CosineSimilarity => {
            info!("Reranker: cosine-similarity (passthrough)");
            Arc::new(CosineSimilarityReranker)
        }
        RerankerConfig::CrossEncoder { url, api_key, model } => {
            info!("Reranker: cross-encoder @ {url} (model={model})");
            Arc::new(CrossEncoderReranker::new(url.clone(), api_key.clone(), model.clone()))
        }
        RerankerConfig::Rrf { k } => {
            info!("Reranker: RRF (k={k})");
            Arc::new(RrfReranker::new(*k))
        }
        RerankerConfig::Weighted { primary, secondary, primary_weight } => {
            info!("Reranker: weighted blend (w={primary_weight})");
            Arc::new(WeightedReranker::new(
                build_from_config(primary),
                build_from_config(secondary),
                *primary_weight,
            ))
        }
    }
}

// ── Implementation 1: CosineSimilarityReranker (default) ──────────────────────

/// Sorts candidates by their stage-1 cosine similarity score.
///
/// This is the default reranker — it applies no additional model,
/// adding zero latency, and preserves the ordering the embedding
/// search already established.
pub struct CosineSimilarityReranker;

#[async_trait]
impl Reranker for CosineSimilarityReranker {
    async fn rerank(
        &self,
        _query: &str,
        mut candidates: Vec<RerankCandidate>,
        top_k: usize,
    ) -> Result<Vec<RerankResult>> {
        // Already scored by cosine sim — just sort descending and trim.
        candidates.sort_unstable_by(|a, b| {
            b.initial_score.partial_cmp(&a.initial_score).unwrap_or(std::cmp::Ordering::Equal)
        });
        candidates.truncate(top_k);

        Ok(candidates.into_iter().enumerate().map(|(i, c)| RerankResult {
            id:    c.id,
            score: c.initial_score,
            rank:  i + 1,
        }).collect())
    }

    fn name(&self) -> &str { "cosine-similarity" }
}

// ── Implementation 2: CrossEncoderReranker ────────────────────────────────────

/// Calls a standard `/v1/rerank` API endpoint.
///
/// Compatible with Cohere, Jina AI, Mixedbread, and any liter-llm proxy
/// that exposes the rerank endpoint. The response format follows the
/// Cohere rerank schema:
///
/// ```json
/// { "results": [{ "index": 2, "relevance_score": 0.98 }, ...] }
/// ```
pub struct CrossEncoderReranker {
    client:  reqwest::Client,
    url:     String,
    api_key: Option<String>,
    model:   String,
}

impl CrossEncoderReranker {
    pub fn new(url: String, api_key: Option<String>, model: String) -> Self {
        Self { client: reqwest::Client::new(), url, api_key, model }
    }
}

#[async_trait]
impl Reranker for CrossEncoderReranker {
    async fn rerank(
        &self,
        query: &str,
        candidates: Vec<RerankCandidate>,
        top_k: usize,
    ) -> Result<Vec<RerankResult>> {
        if candidates.is_empty() {
            return Ok(vec![]);
        }

        let docs: Vec<&str> = candidates.iter().map(|c| c.text.as_str()).collect();
        let body = serde_json::json!({
            "model":      self.model,
            "query":      query,
            "documents":  docs,
            "top_n":      top_k,
        });

        let mut req = self.client.post(&self.url).json(&body);
        if let Some(k) = &self.api_key { req = req.bearer_auth(k); }

        let resp: serde_json::Value = req
            .send().await
            .map_err(|e| MempalaceError::reranker(format!("http: {e}")))?
            .json().await
            .map_err(|e| MempalaceError::reranker(format!("json: {e}")))?;

        let results = resp["results"].as_array()
            .ok_or_else(|| MempalaceError::reranker("missing 'results' in response"))?;

        debug!("CrossEncoder returned {} results", results.len());

        let mut out: Vec<RerankResult> = results.iter().enumerate().filter_map(|(rank, item)| {
            let idx   = item["index"].as_u64()? as usize;
            let score = item["relevance_score"].as_f64()? as f32;
            let cand  = candidates.get(idx)?;
            Some(RerankResult { id: cand.id.clone(), score, rank: rank + 1 })
        }).collect();

        // Ensure we never exceed top_k even if the API returns more.
        out.truncate(top_k);
        Ok(out)
    }

    fn name(&self) -> &str { "cross-encoder" }
}

// ── Implementation 3: RrfReranker ─────────────────────────────────────────────

/// Reciprocal Rank Fusion.
///
/// Combines the original embedding rank with an inverted-score rank using the
/// standard RRF formula: `score = Σ 1 / (k + rank_i)`.
///
/// Useful when you want to give candidates that rank well on *both* cosine
/// similarity *and* recency / importance a boost.
pub struct RrfReranker {
    k: f32,
}

impl RrfReranker {
    /// `k` is the RRF constant; 60.0 is the standard value.
    pub fn new(k: f32) -> Self { Self { k } }
}

#[async_trait]
impl Reranker for RrfReranker {
    async fn rerank(
        &self,
        _query: &str,
        candidates: Vec<RerankCandidate>,
        top_k: usize,
    ) -> Result<Vec<RerankResult>> {
        if candidates.is_empty() { return Ok(vec![]); }

        let n = candidates.len() as f32;

        // Rank 1 by descending initial_score (best embedding match).
        let mut by_score: Vec<(usize, f32)> = candidates.iter()
            .enumerate()
            .map(|(i, c)| (i, c.initial_score))
            .collect();
        by_score.sort_unstable_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));

        let mut rrf_scores = vec![0.0f32; candidates.len()];
        for (rank, (idx, _)) in by_score.iter().enumerate() {
            rrf_scores[*idx] += 1.0 / (self.k + rank as f32 + 1.0);
        }

        let mut indexed: Vec<(usize, f32)> = rrf_scores.into_iter().enumerate().collect();
        indexed.sort_unstable_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        indexed.truncate(top_k);

        Ok(indexed.into_iter().enumerate().map(|(rank, (i, score))| RerankResult {
            id:    candidates[i].id.clone(),
            score,
            rank:  rank + 1,
        }).collect())
    }

    fn name(&self) -> &str { "rrf" }
}

// ── Implementation 4: WeightedReranker ────────────────────────────────────────

/// Linearly blends the scores of two rerankers.
///
/// Final score = `primary_score × w + secondary_score × (1 − w)`.
/// Both rerankers are called concurrently; their scores are then merged by ID.
pub struct WeightedReranker {
    primary:        Arc<dyn Reranker>,
    secondary:      Arc<dyn Reranker>,
    primary_weight: f32,
}

impl WeightedReranker {
    pub fn new(primary: Arc<dyn Reranker>, secondary: Arc<dyn Reranker>, primary_weight: f32) -> Self {
        Self { primary, secondary, primary_weight: primary_weight.clamp(0.0, 1.0) }
    }
}

#[async_trait]
impl Reranker for WeightedReranker {
    async fn rerank(
        &self,
        query: &str,
        candidates: Vec<RerankCandidate>,
        top_k: usize,
    ) -> Result<Vec<RerankResult>> {
        if candidates.is_empty() { return Ok(vec![]); }

        let fetch = candidates.len(); // both sub-rerankers see all candidates
        let (prim_res, sec_res) = tokio::try_join!(
            self.primary.rerank(query, candidates.clone(), fetch),
            self.secondary.rerank(query, candidates.clone(), fetch),
        )?;

        // Build score maps keyed by drawer ID.
        use std::collections::HashMap;
        let mut scores: HashMap<String, f32> = HashMap::new();

        // Normalise primary scores to [0,1] before blending.
        let max_p = prim_res.iter().map(|r| r.score).fold(0.0_f32, f32::max).max(1e-9);
        let max_s = sec_res.iter().map(|r| r.score).fold(0.0_f32, f32::max).max(1e-9);

        for r in &prim_res {
            *scores.entry(r.id.clone()).or_default() +=
                (r.score / max_p) * self.primary_weight;
        }
        for r in &sec_res {
            *scores.entry(r.id.clone()).or_default() +=
                (r.score / max_s) * (1.0 - self.primary_weight);
        }

        let mut ranked: Vec<(String, f32)> = scores.into_iter().collect();
        ranked.sort_unstable_by(|a, b| b.1.partial_cmp(&a.1).unwrap_or(std::cmp::Ordering::Equal));
        ranked.truncate(top_k);

        Ok(ranked.into_iter().enumerate().map(|(i, (id, score))| RerankResult {
            id, score, rank: i + 1,
        }).collect())
    }

    fn name(&self) -> &str { "weighted" }
}
