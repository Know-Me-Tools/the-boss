-- Drawers: verbatim text chunks + embeddings
CREATE TABLE IF NOT EXISTS drawers (
    id           TEXT    PRIMARY KEY,
    wing         TEXT    NOT NULL,
    room         TEXT    NOT NULL DEFAULT '',
    hall         TEXT    NOT NULL DEFAULT '',
    content      TEXT    NOT NULL,
    source_file  TEXT    NOT NULL DEFAULT '',
    chunk_index  INTEGER NOT NULL DEFAULT 0,
    added_by     TEXT    NOT NULL DEFAULT 'mempalace',
    filed_at     TEXT    NOT NULL,
    importance   REAL    NOT NULL DEFAULT 3.0,
    embedding    BLOB             -- NULL until embedded; 384×f32 LE = 1536 bytes
);
CREATE INDEX IF NOT EXISTS idx_drawers_wing      ON drawers (wing);
CREATE INDEX IF NOT EXISTS idx_drawers_room      ON drawers (room);
CREATE INDEX IF NOT EXISTS idx_drawers_wing_room ON drawers (wing, room);
CREATE INDEX IF NOT EXISTS idx_drawers_source    ON drawers (source_file);

-- Knowledge graph
CREATE TABLE IF NOT EXISTS kg_entities (
    id         TEXT PRIMARY KEY,
    name       TEXT NOT NULL,
    type       TEXT NOT NULL DEFAULT 'unknown',
    properties TEXT NOT NULL DEFAULT '{}',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS kg_triples (
    id             TEXT PRIMARY KEY,
    subject        TEXT NOT NULL,
    predicate      TEXT NOT NULL,
    object         TEXT NOT NULL,
    valid_from     TEXT,
    valid_to       TEXT,
    confidence     REAL NOT NULL DEFAULT 1.0,
    source_closet  TEXT,
    source_file    TEXT,
    extracted_at   TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (subject) REFERENCES kg_entities (id),
    FOREIGN KEY (object)  REFERENCES kg_entities (id)
);
CREATE INDEX IF NOT EXISTS idx_triples_subject   ON kg_triples (subject);
CREATE INDEX IF NOT EXISTS idx_triples_object    ON kg_triples (object);
CREATE INDEX IF NOT EXISTS idx_triples_predicate ON kg_triples (predicate);
CREATE INDEX IF NOT EXISTS idx_triples_valid     ON kg_triples (valid_from, valid_to);
