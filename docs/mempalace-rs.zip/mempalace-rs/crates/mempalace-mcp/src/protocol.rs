//! JSON-RPC 2.0 stdio transport — wire-compatible with the Python implementation.

use std::sync::Arc;
use tokio::io::{AsyncBufReadExt, AsyncWriteExt, BufReader};
use tracing::{error, info};
use serde_json::{json, Value};
use mempalace_store::Palace;
use crate::tools::dispatch;

pub async fn serve(palace: Arc<Palace>) -> anyhow::Result<()> {
    info!("MemPalace MCP server starting (stdio)");
    let stdin  = tokio::io::stdin();
    let stdout = tokio::io::stdout();
    let mut reader = BufReader::new(stdin);
    let mut writer = tokio::io::BufWriter::new(stdout);
    let mut line = String::new();
    loop {
        line.clear();
        match reader.read_line(&mut line).await {
            Ok(0) | Err(_) => break,
            Ok(_) => {}
        }
        let trimmed = line.trim();
        if trimmed.is_empty() { continue; }
        let request: Value = match serde_json::from_str(trimmed) {
            Ok(v) => v, Err(e) => { error!("JSON parse: {e}"); continue; }
        };
        if let Some(resp) = handle(&palace, &request).await {
            let mut out = serde_json::to_string(&resp).unwrap_or_default();
            out.push('\n');
            let _ = writer.write_all(out.as_bytes()).await;
            let _ = writer.flush().await;
        }
    }
    Ok(())
}

async fn handle(palace: &Arc<Palace>, req: &Value) -> Option<Value> {
    let id     = req.get("id").cloned().unwrap_or(Value::Null);
    let method = req.get("method")?.as_str()?;
    let params = req.get("params").cloned().unwrap_or(json!({}));

    match method {
        "initialize" => Some(json!({
            "jsonrpc":"2.0","id":id,
            "result":{
                "protocolVersion":"2024-11-05",
                "capabilities":{"tools":{}},
                "serverInfo":{"name":"mempalace","version":"2.0.0"}
            }
        })),
        "notifications/initialized" => None,
        "tools/list" => Some(json!({
            "jsonrpc":"2.0","id":id,
            "result":{"tools": tool_list()}
        })),
        "tools/call" => {
            let name = params.get("name")?.as_str()?;
            let args = params.get("arguments").cloned().unwrap_or(json!({}));
            match dispatch(palace, name, &args).await {
                Ok(result) => Some(json!({
                    "jsonrpc":"2.0","id":id,
                    "result":{"content":[{"type":"text","text": serde_json::to_string_pretty(&result).unwrap_or_default()}]}
                })),
                Err(e) => Some(json!({
                    "jsonrpc":"2.0","id":id,
                    "error":{"code":-32000,"message":e.to_string()}
                })),
            }
        }
        _ => Some(json!({"jsonrpc":"2.0","id":id,"error":{"code":-32601,"message":format!("Unknown method: {method}")}})),
    }
}

fn tool_list() -> Value {
    json!([
        {"name":"mempalace_status",         "description":"Palace overview — drawer counts, wing/room breakdown, AAAK spec","inputSchema":{"type":"object","properties":{}}},
        {"name":"mempalace_list_wings",      "description":"List all wings with drawer counts","inputSchema":{"type":"object","properties":{}}},
        {"name":"mempalace_list_rooms",      "description":"List rooms in a wing","inputSchema":{"type":"object","properties":{"wing":{"type":"string"}}}},
        {"name":"mempalace_get_taxonomy",    "description":"Full wing→room→count tree","inputSchema":{"type":"object","properties":{}}},
        {"name":"mempalace_search",          "description":"Two-stage semantic search (embedding + reranker)","inputSchema":{"type":"object","required":["query"],"properties":{"query":{"type":"string"},"limit":{"type":"integer"},"wing":{"type":"string"},"room":{"type":"string"}}}},
        {"name":"mempalace_check_duplicate", "description":"Check if content already exists in the palace","inputSchema":{"type":"object","required":["content"],"properties":{"content":{"type":"string"},"threshold":{"type":"number"}}}},
        {"name":"mempalace_add_drawer",      "description":"File verbatim content into the palace","inputSchema":{"type":"object","required":["wing","room","content"],"properties":{"wing":{"type":"string"},"room":{"type":"string"},"content":{"type":"string"},"source_file":{"type":"string"},"added_by":{"type":"string"}}}},
        {"name":"mempalace_delete_drawer",   "description":"Delete a drawer by ID","inputSchema":{"type":"object","required":["drawer_id"],"properties":{"drawer_id":{"type":"string"}}}},
        {"name":"mempalace_kg_query",        "description":"Query knowledge graph for an entity","inputSchema":{"type":"object","required":["entity"],"properties":{"entity":{"type":"string"},"as_of":{"type":"string"},"direction":{"type":"string"}}}},
        {"name":"mempalace_kg_add",          "description":"Add a fact to the knowledge graph","inputSchema":{"type":"object","required":["subject","predicate","object"],"properties":{"subject":{"type":"string"},"predicate":{"type":"string"},"object":{"type":"string"},"valid_from":{"type":"string"},"source_closet":{"type":"string"}}}},
        {"name":"mempalace_kg_invalidate",   "description":"Mark a fact as no longer true","inputSchema":{"type":"object","required":["subject","predicate","object"],"properties":{"subject":{"type":"string"},"predicate":{"type":"string"},"object":{"type":"string"},"ended":{"type":"string"}}}},
        {"name":"mempalace_kg_timeline",     "description":"Chronological timeline of facts","inputSchema":{"type":"object","properties":{"entity":{"type":"string"}}}},
        {"name":"mempalace_kg_stats",        "description":"Knowledge graph overview","inputSchema":{"type":"object","properties":{}}},
        {"name":"mempalace_traverse",        "description":"Walk the palace graph from a room","inputSchema":{"type":"object","required":["start_room"],"properties":{"start_room":{"type":"string"},"max_hops":{"type":"integer"}}}},
        {"name":"mempalace_find_tunnels",    "description":"Find rooms bridging two wings","inputSchema":{"type":"object","properties":{"wing_a":{"type":"string"},"wing_b":{"type":"string"}}}},
        {"name":"mempalace_graph_stats",     "description":"Palace graph overview","inputSchema":{"type":"object","properties":{}}},
        {"name":"mempalace_wake_up",         "description":"L0+L1 wake-up context for system prompt injection","inputSchema":{"type":"object","properties":{"wing":{"type":"string"}}}},
        {"name":"mempalace_recall",          "description":"L2 on-demand retrieval filtered by wing/room","inputSchema":{"type":"object","properties":{"wing":{"type":"string"},"room":{"type":"string"},"limit":{"type":"integer"}}}},
        {"name":"mempalace_diary_write",     "description":"Write an agent diary entry (AAAK format)","inputSchema":{"type":"object","required":["agent_name","entry"],"properties":{"agent_name":{"type":"string"},"entry":{"type":"string"},"topic":{"type":"string"}}}},
        {"name":"mempalace_diary_read",      "description":"Read recent agent diary entries","inputSchema":{"type":"object","required":["agent_name"],"properties":{"agent_name":{"type":"string"},"last_n":{"type":"integer"}}}},
    ])
}
