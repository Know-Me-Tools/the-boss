use std::sync::Arc;
use serde_json::{json, Value};
use mempalace_core::{MempalaceError, Result, SearchFilter, TripleInput};
use mempalace_store::Palace;
use mempalace_layers::{Layer3, MemoryStack};
use mempalace_graph::PalaceGraph;
use chrono::Utc;

const PALACE_PROTOCOL: &str = "IMPORTANT — MemPalace Memory Protocol:\n\
1. ON WAKE-UP: Call mempalace_status to load palace overview.\n\
2. BEFORE RESPONDING about any person/project/event: call mempalace_kg_query or mempalace_search FIRST.\n\
3. IF UNSURE about a fact: say \"let me check\" and query the palace.\n\
4. AFTER EACH SESSION: call mempalace_diary_write to record what happened.\n\
5. WHEN FACTS CHANGE: call mempalace_kg_invalidate then mempalace_kg_add.";

const AAAK_SPEC: &str = "AAAK compressed memory dialect:\n\
ENTITIES: 3-letter codes (ALC=Alice, JOR=Jordan, MAX=Max).\n\
EMOTIONS: *warm* *fierce* *raw* *bloom*.\n\
STRUCTURE: FAM: PROJ: ⚠ pipe-separated.\n\
IMPORTANCE: ★ to ★★★★★. DATES: ISO. COUNTS: Nx.\n\
Example: FAM: ALC→♡JOR | 2D(kids): RIL(18,sports) MAX(11,chess+swimming)";

pub async fn dispatch(palace: &Arc<Palace>, name: &str, args: &Value) -> Result<Value> {
    let str_arg = |k: &str| -> Option<String> { args.get(k)?.as_str().map(str::to_string) };
    let usize_arg = |k: &str, def: usize| args.get(k).and_then(|v| v.as_u64()).map(|n| n as usize).unwrap_or(def);
    let f64_arg  = |k: &str, def: f64|   args.get(k).and_then(|v| v.as_f64()).unwrap_or(def);

    match name {
        // ── Status ─────────────────────────────────────────────────────────
        "mempalace_status" => {
            let counts = palace.drawers.wing_room_counts().await?;
            let total  = counts.values().flat_map(|r| r.values()).sum::<usize>();
            let wings: std::collections::HashMap<&str,usize> = counts.iter()
                .map(|(w,rs)| (w.as_str(), rs.values().sum::<usize>())).collect();
            Ok(json!({ "total_drawers": total, "wings": wings,
                        "palace_path": palace.config.palace_path,
                        "reranker": palace.config.reranker,
                        "candidate_factor": palace.config.candidate_factor,
                        "protocol": PALACE_PROTOCOL, "aaak_dialect": AAAK_SPEC }))
        }
        "mempalace_list_wings" => {
            let counts = palace.drawers.wing_room_counts().await?;
            let wings: std::collections::HashMap<&str,usize> = counts.iter()
                .map(|(w,rs)| (w.as_str(), rs.values().sum::<usize>())).collect();
            Ok(json!({ "wings": wings }))
        }
        "mempalace_list_rooms" => {
            let wing = str_arg("wing");
            let counts = palace.drawers.wing_room_counts().await?;
            let rooms = if let Some(w) = &wing { counts.get(w).cloned().unwrap_or_default() }
                        else { counts.into_values().fold(std::collections::HashMap::new(), |mut acc, m| { for (k,v) in m { *acc.entry(k).or_default() += v; } acc }) };
            Ok(json!({ "wing": wing.unwrap_or_else(|| "all".into()), "rooms": rooms }))
        }
        "mempalace_get_taxonomy" => {
            Ok(json!({ "taxonomy": palace.drawers.wing_room_counts().await? }))
        }

        // ── Search ──────────────────────────────────────────────────────────
        "mempalace_search" => {
            let query = str_arg("query").ok_or_else(|| MempalaceError::other("query required"))?;
            let limit = usize_arg("limit", 5);
            let filter = SearchFilter { wing: str_arg("wing"), room: str_arg("room"), ..Default::default() };
            let hits = palace.drawers.search(&query, &filter, limit).await?;
            let results: Vec<Value> = hits.iter().map(|h| json!({
                "text":        h.drawer.content,
                "wing":        h.drawer.wing,
                "room":        h.drawer.room,
                "source_file": h.drawer.source_file,
                "score":       h.score,
                "rank":        h.rank,
            })).collect();
            Ok(json!({ "query": query, "results": results }))
        }
        "mempalace_check_duplicate" => {
            let content   = str_arg("content").ok_or_else(|| MempalaceError::other("content required"))?;
            let threshold = f64_arg("threshold", 0.9) as f32;
            match palace.drawers.check_duplicate(&content, threshold).await? {
                Some((id, sim)) => Ok(json!({ "is_duplicate": true,  "id": id, "similarity": sim })),
                None            => Ok(json!({ "is_duplicate": false })),
            }
        }
        "mempalace_add_drawer" => {
            let wing    = str_arg("wing").ok_or_else(|| MempalaceError::other("wing required"))?;
            let room    = str_arg("room").ok_or_else(|| MempalaceError::other("room required"))?;
            let content = str_arg("content").ok_or_else(|| MempalaceError::other("content required"))?;
            // Dedup check
            if let Some((id, sim)) = palace.drawers.check_duplicate(&content, 0.9).await? {
                return Ok(json!({ "success": false, "reason": "duplicate", "existing_id": id, "similarity": sim }));
            }
            let id = palace.drawers.add(mempalace_core::DrawerInput {
                wing, room, hall: String::new(), content,
                source_file: str_arg("source_file").unwrap_or_default(),
                chunk_index: 0, added_by: str_arg("added_by").unwrap_or_else(|| "mcp".into()), importance: 3.0,
            }).await?;
            Ok(json!({ "success": true, "drawer_id": id }))
        }
        "mempalace_delete_drawer" => {
            let id = str_arg("drawer_id").ok_or_else(|| MempalaceError::other("drawer_id required"))?;
            let ok = palace.drawers.delete(&id).await?;
            Ok(json!({ "success": ok, "drawer_id": id }))
        }

        // ── Knowledge graph ──────────────────────────────────────────────────
        "mempalace_kg_query" => {
            let entity    = str_arg("entity").ok_or_else(|| MempalaceError::other("entity required"))?;
            let as_of     = str_arg("as_of");
            let direction = str_arg("direction").unwrap_or_else(|| "both".into());
            let facts = palace.kg.query_entity(&entity, as_of.as_deref(), &direction).await?;
            Ok(json!({ "entity": entity, "as_of": as_of, "facts": facts, "count": facts.len() }))
        }
        "mempalace_kg_add" => {
            let subject   = str_arg("subject").ok_or_else(|| MempalaceError::other("subject required"))?;
            let predicate = str_arg("predicate").ok_or_else(|| MempalaceError::other("predicate required"))?;
            let object    = str_arg("object").ok_or_else(|| MempalaceError::other("object required"))?;
            let tid = palace.kg.add_triple(TripleInput { subject: subject.clone(), predicate: predicate.clone(), object: object.clone(),
                valid_from: str_arg("valid_from"), valid_to: None, confidence: 1.0,
                source_closet: str_arg("source_closet"), source_file: None }).await?;
            Ok(json!({ "success": true, "triple_id": tid, "fact": format!("{subject} → {predicate} → {object}") }))
        }
        "mempalace_kg_invalidate" => {
            let sub  = str_arg("subject").ok_or_else(|| MempalaceError::other("subject required"))?;
            let pred = str_arg("predicate").ok_or_else(|| MempalaceError::other("predicate required"))?;
            let obj  = str_arg("object").ok_or_else(|| MempalaceError::other("object required"))?;
            palace.kg.invalidate(&sub, &pred, &obj, str_arg("ended").as_deref()).await?;
            Ok(json!({ "success": true, "fact": format!("{sub} → {pred} → {obj}"), "ended": str_arg("ended").unwrap_or_else(|| "today".into()) }))
        }
        "mempalace_kg_timeline" => {
            let entity = str_arg("entity");
            let tl = palace.kg.timeline(entity.as_deref()).await?;
            Ok(json!({ "entity": entity.unwrap_or_else(|| "all".into()), "timeline": tl, "count": tl.len() }))
        }
        "mempalace_kg_stats" => Ok(serde_json::to_value(palace.kg.stats().await?).unwrap_or_default()),

        // ── Graph ────────────────────────────────────────────────────────────
        "mempalace_traverse" => {
            let start = str_arg("start_room").ok_or_else(|| MempalaceError::other("start_room required"))?;
            let hops  = usize_arg("max_hops", 2);
            let graph = PalaceGraph::build(&palace.drawers).await?;
            Ok(graph.traverse(&start, hops))
        }
        "mempalace_find_tunnels" => {
            let graph = PalaceGraph::build(&palace.drawers).await?;
            let tunnels = graph.find_tunnels(str_arg("wing_a").as_deref(), str_arg("wing_b").as_deref());
            Ok(serde_json::to_value(tunnels).unwrap_or_default())
        }
        "mempalace_graph_stats" => {
            let graph = PalaceGraph::build(&palace.drawers).await?;
            Ok(serde_json::to_value(graph.stats()).unwrap_or_default())
        }

        // ── Layer stack ───────────────────────────────────────────────────────
        "mempalace_wake_up" => {
            let stack = MemoryStack::new(palace.drawers.clone(), (*palace.config).clone());
            let text  = stack.wake_up(str_arg("wing").as_deref()).await;
            Ok(json!({ "wake_up_text": text, "token_estimate": text.len()/4 }))
        }
        "mempalace_recall" => {
            let stack = MemoryStack::new(palace.drawers.clone(), (*palace.config).clone());
            let text  = stack.recall(str_arg("wing").as_deref(), str_arg("room").as_deref(), usize_arg("limit",10)).await;
            Ok(json!({ "text": text }))
        }

        // ── Agent diary ───────────────────────────────────────────────────────
        "mempalace_diary_write" => {
            let agent   = str_arg("agent_name").ok_or_else(|| MempalaceError::other("agent_name required"))?;
            let entry   = str_arg("entry").ok_or_else(|| MempalaceError::other("entry required"))?;
            let topic   = str_arg("topic").unwrap_or_else(|| "general".into());
            let wing    = format!("wing_{}", agent.to_lowercase().replace(' ', "_"));
            let now     = Utc::now();
            let id = palace.drawers.add(mempalace_core::DrawerInput {
                wing, room: "diary".into(), hall: "hall_diary".into(), content: entry,
                source_file: String::new(), chunk_index: 0, added_by: agent.clone(), importance: 3.0,
            }).await?;
            Ok(json!({ "success": true, "entry_id": id, "agent": agent, "topic": topic, "timestamp": now.to_rfc3339() }))
        }
        "mempalace_diary_read" => {
            let agent  = str_arg("agent_name").ok_or_else(|| MempalaceError::other("agent_name required"))?;
            let last_n = usize_arg("last_n", 10);
            let wing   = format!("wing_{}", agent.to_lowercase().replace(' ', "_"));
            let filter = SearchFilter { wing: Some(wing), room: Some("diary".into()), ..Default::default() };
            let mut drawers = palace.drawers.get_filtered(&filter, last_n * 2).await?;
            drawers.sort_by(|a, b| b.filed_at.cmp(&a.filed_at));
            drawers.truncate(last_n);
            let entries: Vec<Value> = drawers.iter().map(|d| json!({
                "date":      &d.filed_at[..10.min(d.filed_at.to_string().len())],
                "timestamp": d.filed_at,
                "content":   d.content,
            })).collect();
            Ok(json!({ "agent": agent, "entries": entries, "showing": entries.len() }))
        }

        _ => Err(MempalaceError::other(format!("Unknown tool: {name}"))),
    }
}
