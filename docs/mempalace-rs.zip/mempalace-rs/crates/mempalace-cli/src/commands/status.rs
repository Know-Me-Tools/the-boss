use std::sync::Arc;
use mempalace_store::Palace;
use anyhow::Result;

pub async fn run(palace: &Arc<Palace>) -> Result<()> {
    let counts = palace.drawers.wing_room_counts().await?;
    let total: usize = counts.values().flat_map(|r| r.values()).sum();
    println!("\n{}", "═".repeat(55));
    println!("  MemPalace Status — {total} drawers");
    println!("  Reranker: {}", palace.config.reranker_name());
    println!("  Candidate factor: {}×", palace.config.candidate_factor);
    println!("{}\n", "═".repeat(55));
    let mut wings: Vec<(&String, &std::collections::HashMap<String,usize>)> = counts.iter().collect();
    wings.sort_by_key(|(w,_)| w.as_str());
    for (wing, rooms) in wings {
        println!("  WING: {wing}");
        let mut rs: Vec<(&String,&usize)> = rooms.iter().collect();
        rs.sort_by_key(|(_,n)| std::cmp::Reverse(**n));
        for (r,n) in rs { println!("    ROOM: {r:20} {n:5} drawers"); }
        println!();
    }
    println!("{}\n", "═".repeat(55));
    Ok(())
}
