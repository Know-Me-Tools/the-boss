use std::path::Path;
use mempalace_core::MempalaceConfig;
use mempalace_miner::{mine_convos, ConvoMineOptions};
use mempalace_store::Palace;
use anyhow::Result;

pub async fn run(cfg: &MempalaceConfig, convo_dir: &str, wing: Option<String>, agent: Option<String>, limit: Option<usize>, dry_run: bool) -> Result<()> {
    let palace = Palace::open(cfg.clone()).await?;
    let opts = ConvoMineOptions { wing, agent: agent.unwrap_or_else(|| "mempalace".into()), limit: limit.unwrap_or(0), dry_run };
    let res = mine_convos(Path::new(convo_dir), &palace.drawers, opts).await?;
    println!("\nConvo mine done — {} drawers from {}/{} files", res.drawers_filed, res.files_processed, res.total_files);
    Ok(())
}
