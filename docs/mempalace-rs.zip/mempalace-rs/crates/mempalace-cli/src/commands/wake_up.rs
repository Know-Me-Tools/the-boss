use std::sync::Arc;
use mempalace_layers::MemoryStack;
use mempalace_store::Palace;
use anyhow::Result;

pub async fn run(palace: &Arc<Palace>, wing: Option<&str>) -> Result<()> {
    let stack = MemoryStack::new(palace.drawers.clone(), (*palace.config).clone());
    let text  = stack.wake_up(wing).await;
    let tokens = text.len() / 4;
    println!("Wake-up context (~{tokens} tokens):");
    println!("{}", "═".repeat(50));
    println!("{text}");
    Ok(())
}
