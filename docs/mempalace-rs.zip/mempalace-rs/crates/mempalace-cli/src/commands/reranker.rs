use mempalace_core::{MempalaceConfig, RerankerConfig};

pub fn run(cfg: &MempalaceConfig) {
    println!("\n{}", "═".repeat(55));
    println!("  MemPalace Reranker Configuration");
    println!("{}", "─".repeat(55));
    match &cfg.reranker {
        RerankerConfig::CosineSimilarity => {
            println!("  Type           : cosine-similarity (default)");
            println!("  Description    : Sorts by stage-1 embedding score.");
            println!("                   Zero extra latency, no API key needed.");
        }
        RerankerConfig::CrossEncoder { url, model, api_key } => {
            println!("  Type           : cross-encoder");
            println!("  URL            : {url}");
            println!("  Model          : {model}");
            println!("  API key        : {}", if api_key.is_some() { "set" } else { "not set" });
            println!("  Compatible with: Cohere, Jina, Mixedbread, liter-llm /v1/rerank");
        }
        RerankerConfig::Rrf { k } => {
            println!("  Type           : reciprocal-rank-fusion");
            println!("  k constant     : {k}");
        }
        RerankerConfig::Weighted { primary, secondary, primary_weight } => {
            println!("  Type           : weighted blend");
            println!("  Primary weight : {primary_weight:.2}");
            println!("  Primary        : {:?}", primary);
            println!("  Secondary      : {:?}", secondary);
        }
    }
    println!("  Candidate factor: {}× (stage-1 fetches {}× the requested limit)", cfg.candidate_factor, cfg.candidate_factor);
    println!("{}\n", "═".repeat(55));
}
