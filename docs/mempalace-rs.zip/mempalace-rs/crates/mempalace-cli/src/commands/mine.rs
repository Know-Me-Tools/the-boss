use std::path::Path;
use mempalace_core::MempalaceConfig;
use mempalace_miner::{mine, MineOptions};
use mempalace_store::Palace;
use anyhow::Result;

pub async fn run(cfg: &MempalaceConfig, project_dir: &str, wing: Option<String>, agent: Option<String>, limit: Option<usize>, dry_run: bool) -> Result<()> {
    let palace = Palace::open(cfg.clone()).await?;
    let opts = MineOptions { wing_override: wing, agent: agent.unwrap_or_else(|| "mempalace".into()), limit: limit.unwrap_or(0), dry_run };
    let res = mine(Path::new(project_dir), &palace.drawers, opts).await?;
    println!("\n{}", "═".repeat(55));
    println!("  MemPalace Mine — Done");
    println!("{}", "─".repeat(55));
    println!("  Files processed : {}/{}", res.files_processed, res.total_files);
    println!("  Files skipped   : {}", res.files_skipped);
    println!("  Drawers filed   : {}", res.drawers_filed);
    if !res.by_room.is_empty() {
        println!("\n  By room:");
        let mut rooms: Vec<(&String,&usize)> = res.by_room.iter().collect();
        rooms.sort_by_key(|(_,n)| std::cmp::Reverse(**n));
        for (r,n) in rooms { println!("    {r:20} {n} files"); }
    }
    println!("{}\n", "═".repeat(55));
    Ok(())
}
