use std::sync::Arc;
use mempalace_layers::MemoryStack;
use mempalace_store::Palace;
use anyhow::Result;

pub async fn run(palace: &Arc<Palace>, wing: Option<&str>, room: Option<&str>, limit: usize) -> Result<()> {
    let stack = MemoryStack::new(palace.drawers.clone(), (*palace.config).clone());
    println!("{}", stack.recall(wing, room, limit).await);
    Ok(())
}
