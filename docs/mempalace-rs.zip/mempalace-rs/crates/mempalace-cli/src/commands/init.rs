use mempalace_core::{MempalaceConfig, Result};
pub fn run(cfg: &MempalaceConfig) -> Result<()> {
    let path = cfg.init()?;
    println!("✓ Initialised palace config at {}", path.display());
    println!("  Next: mempalace mine <project_dir>");
    Ok(())
}
