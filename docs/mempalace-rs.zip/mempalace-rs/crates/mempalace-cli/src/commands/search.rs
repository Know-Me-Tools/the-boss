use std::sync::Arc;
use mempalace_store::Palace;
use anyhow::Result;

pub async fn run(palace: &Arc<Palace>, query: &str, wing: Option<&str>, room: Option<&str>, limit: usize) -> Result<()> {
    use mempalace_core::SearchFilter;
    let filter = SearchFilter { wing: wing.map(str::to_string), room: room.map(str::to_string), ..Default::default() };
    let hits = palace.drawers.search(query, &filter, limit).await?;
    println!("\n{}", "═".repeat(60));
    println!("  Results for: \"{query}\" (reranker={})", palace.config.reranker_name());
    if let Some(w) = wing { println!("  Wing: {w}"); }
    if let Some(r) = room { println!("  Room: {r}"); }
    println!("{}\n", "═".repeat(60));
    if hits.is_empty() { println!("  No results found.\n"); return Ok(()); }
    for h in &hits {
        let d = &h.drawer;
        let src = std::path::Path::new(&d.source_file).file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
        println!("  [{}] {} / {}  (score={:.3})", h.rank, d.wing, d.room, h.score);
        if !src.is_empty() { println!("      src: {src}"); }
        println!();
        for line in d.content.trim().lines().take(10) { println!("      {line}"); }
        println!("\n  {}", "─".repeat(56));
    }
    println!();
    Ok(())
}
