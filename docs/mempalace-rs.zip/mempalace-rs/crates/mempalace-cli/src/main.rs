#[cfg(not(target_env = "msvc"))]
use tikv_jemallocator::Jemalloc;
#[cfg(not(target_env = "msvc"))]
#[global_allocator]
static ALLOC: Jemalloc = Jemalloc;

use std::sync::Arc;
use anyhow::Result;
use clap::{Parser, Subcommand};
use tracing_subscriber::{fmt, EnvFilter};

use mempalace_core::MempalaceConfig;
use mempalace_store::Palace;

mod commands;

#[derive(Parser)]
#[command(name = "mempalace", about = "Give your AI a memory — no API key required", version)]
struct Cli {
    #[command(subcommand)]
    command: Cmd,
}

#[derive(Subcommand)]
enum Cmd {
    /// Initialise palace config in ~/.mempalace
    Init,
    /// Mine a project directory into the palace
    Mine {
        project_dir: String,
        #[arg(long)] wing:    Option<String>,
        #[arg(long)] agent:   Option<String>,
        #[arg(long)] limit:   Option<usize>,
        #[arg(long)] dry_run: bool,
    },
    /// Mine conversation exports into the palace
    MineConvos {
        convo_dir: String,
        #[arg(long)] wing:    Option<String>,
        #[arg(long)] agent:   Option<String>,
        #[arg(long)] limit:   Option<usize>,
        #[arg(long)] dry_run: bool,
    },
    /// Semantic search the palace
    Search {
        query: Vec<String>,
        #[arg(long)] wing:  Option<String>,
        #[arg(long)] room:  Option<String>,
        #[arg(long, default_value = "5")] limit: usize,
    },
    /// Show palace status
    Status,
    /// Show L0+L1 wake-up context
    WakeUp {
        #[arg(long)] wing: Option<String>,
    },
    /// L2 on-demand retrieval
    Recall {
        #[arg(long)] wing:  Option<String>,
        #[arg(long)] room:  Option<String>,
        #[arg(long, default_value = "10")] limit: usize,
    },
    /// Start the MCP server (JSON-RPC stdio)
    Mcp,
    /// Show reranker configuration
    Reranker,
}

#[tokio::main]
async fn main() -> Result<()> {
    tracing_subscriber::fmt()
        .with_env_filter(EnvFilter::from_default_env().add_directive("mempalace=info".parse()?))
        .with_writer(std::io::stderr)
        .compact()
        .init();

    let cli = Cli::parse();
    let cfg = MempalaceConfig::load();

    match cli.command {
        Cmd::Init => commands::init::run(&cfg)?,

        Cmd::Mine { project_dir, wing, agent, limit, dry_run } =>
            commands::mine::run(&cfg, &project_dir, wing, agent, limit, dry_run).await?,

        Cmd::MineConvos { convo_dir, wing, agent, limit, dry_run } =>
            commands::mine_convos::run(&cfg, &convo_dir, wing, agent, limit, dry_run).await?,

        Cmd::Search { query, wing, room, limit } => {
            let q = query.join(" ");
            let palace = Arc::new(Palace::open(cfg).await?);
            commands::search::run(&palace, &q, wing.as_deref(), room.as_deref(), limit).await?;
        }

        Cmd::Status => {
            let palace = Arc::new(Palace::open(cfg).await?);
            commands::status::run(&palace).await?;
        }

        Cmd::WakeUp { wing } => {
            let palace = Arc::new(Palace::open(cfg).await?);
            commands::wake_up::run(&palace, wing.as_deref()).await?;
        }

        Cmd::Recall { wing, room, limit } => {
            let palace = Arc::new(Palace::open(cfg).await?);
            commands::recall::run(&palace, wing.as_deref(), room.as_deref(), limit).await?;
        }

        Cmd::Mcp => {
            let palace = Arc::new(Palace::open(cfg).await?);
            mempalace_mcp::serve(palace).await?;
        }

        Cmd::Reranker => commands::reranker::run(&cfg),
    }

    Ok(())
}
