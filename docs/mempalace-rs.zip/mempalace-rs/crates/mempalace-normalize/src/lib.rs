//! Normalise any chat export to a unified `> user\nassistant\n` transcript.

use std::path::Path;
use serde_json::Value;
use tracing::debug;
use mempalace_core::Chunk;

// ── Entry points ──────────────────────────────────────────────────────────────

pub fn normalize_file(path: &Path) -> std::io::Result<String> {
    let content = std::fs::read_to_string(path)?;
    let ext = path.extension().and_then(|e| e.to_str());
    Ok(normalize_str(&content, ext))
}

pub fn normalize_str(content: &str, ext: Option<&str>) -> String {
    if content.trim().is_empty() { return content.to_string(); }
    let quotes = content.lines().filter(|l| l.trim().starts_with('>')).count();
    if quotes >= 3 { return content.to_string(); }
    if matches!(ext, Some("json") | Some("jsonl"))
        || content.trim_start().starts_with('{')
        || content.trim_start().starts_with('[')
    {
        if let Some(n) = try_json(content) { return n; }
    }
    content.to_string()
}

fn try_json(content: &str) -> Option<String> {
    if let Some(t) = try_claude_code_jsonl(content) { return Some(t); }
    let data: Value = serde_json::from_str(content).ok()?;
    try_claude_ai(&data).or_else(|| try_chatgpt(&data)).or_else(|| try_slack(&data))
}

// ── Claude Code JSONL ─────────────────────────────────────────────────────────
fn try_claude_code_jsonl(content: &str) -> Option<String> {
    let mut msgs: Vec<(R, String)> = Vec::new();
    for line in content.lines().map(str::trim).filter(|l| !l.is_empty()) {
        let e: Value = serde_json::from_str(line).ok()?;
        let t = e.get("type")?.as_str()?;
        let text = extract_content(e.get("message")?.get("content")?);
        if text.is_empty() { continue; }
        match t { "human" => msgs.push((R::U, text)), "assistant" => msgs.push((R::A, text)), _ => {} }
    }
    if msgs.len() >= 2 { debug!("Claude Code JSONL: {} turns", msgs.len()); Some(to_transcript(msgs)) } else { None }
}

// ── Claude.ai JSON ────────────────────────────────────────────────────────────
fn try_claude_ai(data: &Value) -> Option<String> {
    let list: &[Value] = match data {
        Value::Array(a) => a,
        Value::Object(o) => o.get("messages").or_else(|| o.get("chat_messages"))?.as_array()?,
        _ => return None,
    };
    let msgs: Vec<(R,String)> = list.iter().filter_map(|item| {
        let role = item.get("role")?.as_str()?;
        let text = extract_content(item.get("content")?);
        if text.is_empty() { return None; }
        match role { "user"|"human" => Some((R::U,text)), "assistant"|"ai" => Some((R::A,text)), _ => None }
    }).collect();
    if msgs.len() >= 2 { Some(to_transcript(msgs)) } else { None }
}

// ── ChatGPT JSON ──────────────────────────────────────────────────────────────
fn try_chatgpt(data: &Value) -> Option<String> {
    let mapping = data.get("mapping")?.as_object()?;
    let root = mapping.iter()
        .find(|(_, n)| n.get("parent").is_none_or(|p| p.is_null()) && n.get("message").is_none())
        .or_else(|| mapping.iter().find(|(_, n)| n.get("parent").is_none_or(|p| p.is_null())))
        .map(|(id, _)| id.clone())?;
    let mut msgs: Vec<(R,String)> = Vec::new();
    let mut cur = root;
    let mut seen = std::collections::HashSet::new();
    loop {
        if !seen.insert(cur.clone()) { break; }
        let node = mapping.get(&cur)?;
        if let Some(msg) = node.get("message") {
            let role = msg.get("author").and_then(|a| a.get("role")).and_then(|r| r.as_str()).unwrap_or("");
            let text: String = msg.get("content").and_then(|c| c.get("parts")).and_then(|p| p.as_array())
                .map(|a| a.iter().filter_map(|p| p.as_str()).filter(|s| !s.is_empty()).collect::<Vec<_>>().join(" "))
                .unwrap_or_default();
            if !text.is_empty() { match role { "user" => msgs.push((R::U,text)), "assistant" => msgs.push((R::A,text)), _ => {} } }
        }
        match node.get("children").and_then(|c| c.as_array()).and_then(|c| c.first()).and_then(|c| c.as_str()) {
            Some(n) => cur = n.to_string(), None => break,
        }
    }
    if msgs.len() >= 2 { Some(to_transcript(msgs)) } else { None }
}

// ── Slack JSON ────────────────────────────────────────────────────────────────
fn try_slack(data: &Value) -> Option<String> {
    let list = data.as_array()?;
    let mut msgs: Vec<(R,String)> = Vec::new();
    let mut seen: std::collections::HashMap<String, R> = std::collections::HashMap::new();
    let mut last = R::U;
    for item in list {
        if item.get("type").and_then(|t| t.as_str()) != Some("message") { continue; }
        let user = item.get("user").or_else(|| item.get("username")).and_then(|u| u.as_str()).unwrap_or("").to_string();
        let text = item.get("text").and_then(|t| t.as_str()).unwrap_or("").trim().to_string();
        if text.is_empty() || user.is_empty() { continue; }
        let r = seen.entry(user).or_insert_with(|| if seen.is_empty() { R::U } else if last == R::U { R::A } else { R::U }).clone();
        last = r.clone();
        msgs.push((r, text));
    }
    if msgs.len() >= 2 { Some(to_transcript(msgs)) } else { None }
}

// ── Helpers ───────────────────────────────────────────────────────────────────
#[derive(Clone,PartialEq)] enum R { U, A }

fn extract_content(v: &Value) -> String {
    match v {
        Value::String(s) => s.trim().to_string(),
        Value::Array(a) => a.iter().filter_map(|i| match i {
            Value::String(s) => Some(s.as_str()),
            Value::Object(o) if o.get("type").and_then(|t| t.as_str()) == Some("text") =>
                o.get("text").and_then(|t| t.as_str()),
            _ => None,
        }).filter(|s| !s.is_empty()).collect::<Vec<_>>().join(" ").trim().to_string(),
        Value::Object(o) => o.get("text").and_then(|t| t.as_str()).unwrap_or("").trim().to_string(),
        _ => String::new(),
    }
}

fn to_transcript(msgs: Vec<(R, String)>) -> String {
    let mut lines: Vec<String> = Vec::new();
    let mut i = 0;
    while i < msgs.len() {
        let (ref role, ref text) = msgs[i];
        if *role == R::U {
            lines.push(format!("> {text}"));
            if i+1 < msgs.len() && msgs[i+1].0 == R::A { lines.push(msgs[i+1].1.clone()); i += 2; } else { i += 1; }
        } else { lines.push(text.clone()); i += 1; }
        lines.push(String::new());
    }
    lines.join("\n")
}

// ── Chunking ──────────────────────────────────────────────────────────────────
const MIN_CHUNK: usize = 30;

pub fn chunk_exchanges(content: &str) -> Vec<Chunk> {
    let lines: Vec<&str> = content.lines().collect();
    if lines.iter().filter(|l| l.trim().starts_with('>')).count() >= 3 {
        chunk_by_exchange(&lines)
    } else {
        chunk_by_paragraph(content)
    }
}

fn chunk_by_exchange(lines: &[&str]) -> Vec<Chunk> {
    let mut chunks = Vec::new();
    let mut i = 0;
    while i < lines.len() {
        if lines[i].trim().starts_with('>') {
            let user = lines[i].trim().to_string();
            i += 1;
            let mut ai = Vec::new();
            while i < lines.len() && !lines[i].trim().starts_with('>') && !lines[i].trim().starts_with("---") {
                if !lines[i].trim().is_empty() { ai.push(lines[i].trim()); } i += 1;
            }
            let content = if ai.is_empty() { user } else { format!("{user}\n{}", ai[..ai.len().min(8)].join(" ")) };
            if content.trim().len() > MIN_CHUNK {
                let idx = chunks.len();
                chunks.push(Chunk { content, chunk_index: idx, memory_type: None });
            }
        } else { i += 1; }
    }
    chunks
}

fn chunk_by_paragraph(content: &str) -> Vec<Chunk> {
    let mut chunks = Vec::new();
    let paras: Vec<&str> = content.split("\n\n").map(str::trim).filter(|p| !p.is_empty()).collect();
    if paras.len() <= 1 && content.lines().count() > 20 {
        for group in content.lines().collect::<Vec<_>>().chunks(25) {
            let t = group.join("\n").trim().to_string();
            if t.len() > MIN_CHUNK { let idx = chunks.len(); chunks.push(Chunk { content: t, chunk_index: idx, memory_type: None }); }
        }
        return chunks;
    }
    for p in paras {
        if p.len() > MIN_CHUNK { let idx = chunks.len(); chunks.push(Chunk { content: p.to_string(), chunk_index: idx, memory_type: None }); }
    }
    chunks
}

const TOPIC_KW: &[(&str, &[&str])] = &[
    ("technical",    &["code","function","bug","error","api","database","server","deploy","git","test","debug"]),
    ("architecture", &["architecture","design","pattern","schema","interface","module","component","service"]),
    ("planning",     &["plan","roadmap","milestone","deadline","priority","sprint","backlog","scope","spec"]),
    ("decisions",    &["decided","chose","picked","switched","migrated","replaced","trade-off","alternative"]),
    ("problems",     &["problem","issue","broken","failed","crash","stuck","workaround","fix","solved"]),
];

pub fn detect_convo_room(content: &str) -> String {
    let lower = content[..content.len().min(3000)].to_lowercase();
    TOPIC_KW.iter()
        .map(|(r, kws)| (*r, kws.iter().filter(|&&kw| lower.contains(kw)).count()))
        .filter(|(_, n)| *n > 0)
        .max_by_key(|(_, n)| *n)
        .map(|(r, _)| r.to_string())
        .unwrap_or_else(|| "general".to_string())
}
