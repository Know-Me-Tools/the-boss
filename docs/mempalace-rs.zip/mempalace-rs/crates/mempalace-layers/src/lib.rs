use std::collections::HashMap;
use mempalace_core::{default_identity_path, L0Status, LayerDesc, LayerStatus, MempalaceConfig, Result, SearchFilter, SearchResult};
use mempalace_store::DrawerStore;

// ── Layer 0 ───────────────────────────────────────────────────────────────────
pub struct Layer0 { path: std::path::PathBuf, cached: std::sync::OnceLock<String> }
impl Layer0 {
    pub fn new(path: Option<std::path::PathBuf>) -> Self {
        Self { path: path.unwrap_or_else(default_identity_path), cached: std::sync::OnceLock::new() }
    }
    pub fn render(&self) -> &str {
        self.cached.get_or_init(|| {
            if self.path.exists() { std::fs::read_to_string(&self.path).unwrap_or_default().trim().to_string() }
            else { "## L0 — IDENTITY\nNo identity configured. Create ~/.mempalace/identity.txt".to_string() }
        })
    }
    pub fn token_estimate(&self) -> usize { self.render().len() / 4 }
    pub fn status(&self) -> L0Status { L0Status { path: self.path.to_string_lossy().into_owned(), exists: self.path.exists(), tokens_estimate: self.token_estimate() } }
}

// ── Layer 1 ───────────────────────────────────────────────────────────────────
pub struct Layer1<'a> { store: &'a DrawerStore, wing: Option<String> }
impl<'a> Layer1<'a> {
    pub fn new(store: &'a DrawerStore) -> Self { Self { store, wing: None } }
    pub fn with_wing(mut self, w: impl Into<String>) -> Self { self.wing = Some(w.into()); self }
    pub async fn generate(&self) -> String {
        let filter = SearchFilter { wing: self.wing.clone(), ..Default::default() };
        let drawers = match self.store.get_filtered(&filter, 200).await { Ok(d) => d, Err(_) => return "## L1 — No palace found. Run: mempalace mine <dir>".into() };
        if drawers.is_empty() { return "## L1 — No memories yet.".into(); }
        let mut by_room: HashMap<String, Vec<&mempalace_core::Drawer>> = HashMap::new();
        for d in drawers.iter().take(15) { by_room.entry(d.room.clone()).or_default().push(d); }
        let mut lines = vec!["## L1 — ESSENTIAL STORY".to_string()];
        let mut total = 0usize;
        let mut rooms: Vec<(&String, &Vec<&mempalace_core::Drawer>)> = by_room.iter().collect();
        rooms.sort_by_key(|(r, _)| r.as_str());
        'o: for (room, entries) in rooms {
            let rl = format!("\n[{room}]"); lines.push(rl.clone()); total += rl.len();
            for d in entries {
                let src = std::path::Path::new(&d.source_file).file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
                let snip = { let s = d.content.replace('\n'," "); if s.len()>200 { format!("{}...", &s[..197]) } else { s } };
                let entry = if src.is_empty() { format!("  - {snip}") } else { format!("  - {snip}  ({src})") };
                if total + entry.len() > 3200 { lines.push("  ... (more in L3 search)".into()); break 'o; }
                total += entry.len(); lines.push(entry);
            }
        }
        lines.join("\n")
    }
}

// ── Layer 2 ───────────────────────────────────────────────────────────────────
pub struct Layer2<'a> { store: &'a DrawerStore }
impl<'a> Layer2<'a> {
    pub fn new(store: &'a DrawerStore) -> Self { Self { store } }
    pub async fn retrieve(&self, wing: Option<&str>, room: Option<&str>, n: usize) -> String {
        let filter = SearchFilter { wing: wing.map(str::to_string), room: room.map(str::to_string), ..Default::default() };
        let drawers = match self.store.get_filtered(&filter, n).await { Ok(d) => d, Err(e) => return format!("Retrieval error: {e}") };
        if drawers.is_empty() { return "No drawers found.".into(); }
        let mut lines = vec![format!("## L2 — ON-DEMAND ({} drawers)", drawers.len())];
        for d in &drawers {
            let src = std::path::Path::new(&d.source_file).file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
            let snip = { let s = d.content.replace('\n'," "); if s.len()>300 { format!("{}...", &s[..297]) } else { s } };
            lines.push(if src.is_empty() { format!("  [{}] {snip}", d.room) } else { format!("  [{}] {snip}  ({src})", d.room) });
        }
        lines.join("\n")
    }
}

// ── Layer 3 ───────────────────────────────────────────────────────────────────
pub struct Layer3<'a> { store: &'a DrawerStore }
impl<'a> Layer3<'a> {
    pub fn new(store: &'a DrawerStore) -> Self { Self { store } }
    pub async fn search(&self, query: &str, wing: Option<&str>, room: Option<&str>, n: usize) -> String {
        let filter = SearchFilter { wing: wing.map(str::to_string), room: room.map(str::to_string), ..Default::default() };
        let hits = match self.store.search(query, &filter, n).await { Ok(h) => h, Err(e) => return format!("Search error: {e}") };
        if hits.is_empty() { return "No results found.".into(); }
        let mut lines = vec![format!("## L3 — SEARCH RESULTS for \"{query}\"")];
        for h in &hits {
            let d = &h.drawer;
            let src = std::path::Path::new(&d.source_file).file_name().map(|n| n.to_string_lossy().into_owned()).unwrap_or_default();
            let snip = { let s = d.content.replace('\n'," "); if s.len()>300 { format!("{}...", &s[..297]) } else { s } };
            lines.push(format!("  [{}] {}/{} (score={:.3} rank={})", h.rank, d.wing, d.room, h.score, h.rank));
            lines.push(format!("      {snip}"));
            if !src.is_empty() { lines.push(format!("      src: {src}")); }
        }
        lines.join("\n")
    }
    pub async fn search_raw(&self, query: &str, wing: Option<&str>, room: Option<&str>, n: usize) -> Result<Vec<SearchResult>> {
        let filter = SearchFilter { wing: wing.map(str::to_string), room: room.map(str::to_string), ..Default::default() };
        self.store.search(query, &filter, n).await
    }
}

// ── MemoryStack ───────────────────────────────────────────────────────────────
pub struct MemoryStack { pub store: DrawerStore, pub l0: Layer0, pub config: MempalaceConfig }
impl MemoryStack {
    pub fn new(store: DrawerStore, config: MempalaceConfig) -> Self {
        Self { l0: Layer0::new(Some(default_identity_path())), store, config }
    }
    pub async fn wake_up(&self, wing: Option<&str>) -> String {
        let l0 = self.l0.render().to_string();
        let l1 = Layer1::new(&self.store);
        let l1 = if let Some(w) = wing { l1.with_wing(w) } else { l1 };
        format!("{l0}\n\n{}", l1.generate().await)
    }
    pub async fn recall(&self, wing: Option<&str>, room: Option<&str>, n: usize) -> String {
        Layer2::new(&self.store).retrieve(wing, room, n).await
    }
    pub async fn search(&self, query: &str, wing: Option<&str>, room: Option<&str>, n: usize) -> String {
        Layer3::new(&self.store).search(query, wing, room, n).await
    }
    pub async fn status(&self) -> Result<LayerStatus> {
        Ok(LayerStatus {
            palace_path:    self.config.palace_path.to_string_lossy().into_owned(),
            l0_identity:    self.l0.status(),
            l1_essential:   LayerDesc { description: "Auto-generated from top palace drawers".into() },
            l2_on_demand:   LayerDesc { description: "Wing/room filtered retrieval".into() },
            l3_deep_search: LayerDesc { description: "Semantic search (embedding + reranker)".into() },
            total_drawers:  self.store.count().await?,
        })
    }
}
