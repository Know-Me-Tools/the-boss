use std::collections::{HashMap, HashSet};
use mempalace_core::{Result, TraversalHop};
use mempalace_store::{DrawerMeta, DrawerStore};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomNode { pub room: String, pub wings: Vec<String>, pub halls: Vec<String>, pub count: usize, pub recent_dates: Vec<String> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphStats { pub total_rooms: usize, pub tunnel_rooms: usize, pub total_edges: usize, pub rooms_per_wing: HashMap<String, usize>, pub top_tunnels: Vec<TunnelInfo> }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TunnelInfo { pub room: String, pub wings: Vec<String>, pub count: usize }

pub struct PalaceGraph { nodes: HashMap<String, RoomNode> }

impl PalaceGraph {
    pub async fn build(store: &DrawerStore) -> Result<Self> {
        let metas: Vec<DrawerMeta> = store.get_all_meta().await?;
        let mut data: HashMap<String, (HashSet<String>, HashSet<String>, usize, Vec<String>)> = HashMap::new();
        for m in metas {
            if m.room.is_empty() || m.room == "general" || m.wing.is_empty() { continue; }
            let e = data.entry(m.room.clone()).or_default();
            e.0.insert(m.wing.clone());
            if !m.hall.is_empty() { e.1.insert(m.hall.clone()); }
            e.2 += 1;
            if !m.filed_at.is_empty() { e.3.push(m.filed_at[..10.min(m.filed_at.len())].to_string()); }
        }
        let nodes = data.into_iter().map(|(room, (wings, halls, count, mut dates))| {
            dates.sort(); dates.dedup(); let recent = dates.into_iter().rev().take(5).collect::<Vec<_>>().into_iter().rev().collect();
            let mut ws: Vec<String> = wings.into_iter().collect(); ws.sort();
            let mut hs: Vec<String> = halls.into_iter().collect(); hs.sort();
            (room.clone(), RoomNode { room, wings: ws, halls: hs, count, recent_dates: recent })
        }).collect();
        Ok(Self { nodes })
    }

    /// BFS from `start_room` following shared-wing edges.
    pub fn traverse(&self, start_room: &str, max_hops: usize) -> serde_json::Value {
        if !self.nodes.contains_key(start_room) {
            let suggestions: Vec<&str> = self.nodes.keys()
                .filter(|r| r.contains(start_room) || start_room.split('-').any(|w| r.contains(w)))
                .map(|s| s.as_str()).take(5).collect();
            return serde_json::json!({ "error": format!("Room '{start_room}' not found"), "suggestions": suggestions });
        }
        let mut visited = HashSet::new();
        let mut results: Vec<TraversalHop> = Vec::new();
        let mut frontier: Vec<(String, usize)> = vec![(start_room.to_string(), 0)];
        visited.insert(start_room.to_string());
        let start = &self.nodes[start_room];
        results.push(TraversalHop { room: start_room.to_string(), wings: start.wings.clone(), halls: start.halls.clone(), count: start.count, hop: 0, connected_via: None });

        while let Some((cur, depth)) = frontier.first().cloned() {
            frontier.remove(0);
            if depth >= max_hops { continue; }
            let cur_wings: HashSet<&str> = self.nodes[&cur].wings.iter().map(String::as_str).collect();
            for (room, node) in &self.nodes {
                if visited.contains(room.as_str()) { continue; }
                let shared: Vec<String> = node.wings.iter().filter(|w| cur_wings.contains(w.as_str())).cloned().collect();
                if !shared.is_empty() {
                    visited.insert(room.clone());
                    results.push(TraversalHop { room: room.clone(), wings: node.wings.clone(), halls: node.halls.clone(), count: node.count, hop: depth+1, connected_via: Some(shared) });
                    if depth+1 < max_hops { frontier.push((room.clone(), depth+1)); }
                }
            }
        }
        results.sort_by_key(|h| (h.hop, usize::MAX - h.count));
        results.truncate(50);
        serde_json::to_value(results).unwrap_or_default()
    }

    /// Rooms that appear in 2+ wings (the "tunnels").
    pub fn find_tunnels(&self, wing_a: Option<&str>, wing_b: Option<&str>) -> Vec<TunnelInfo> {
        let mut tunnels: Vec<TunnelInfo> = self.nodes.values()
            .filter(|n| n.wings.len() >= 2)
            .filter(|n| wing_a.map(|w| n.wings.contains(&w.to_string())).unwrap_or(true))
            .filter(|n| wing_b.map(|w| n.wings.contains(&w.to_string())).unwrap_or(true))
            .map(|n| TunnelInfo { room: n.room.clone(), wings: n.wings.clone(), count: n.count })
            .collect();
        tunnels.sort_by(|a, b| b.count.cmp(&a.count));
        tunnels.truncate(50);
        tunnels
    }

    pub fn stats(&self) -> GraphStats {
        let tunnel_rooms = self.nodes.values().filter(|n| n.wings.len() >= 2).count();
        let total_edges  = self.nodes.values().filter(|n| n.wings.len() >= 2)
            .map(|n| { let w = n.wings.len(); w*(w-1)/2 }).sum();
        let mut rpw: HashMap<String,usize> = HashMap::new();
        for n in self.nodes.values() { for w in &n.wings { *rpw.entry(w.clone()).or_default() += 1; } }
        let mut top: Vec<TunnelInfo> = self.nodes.values().filter(|n| n.wings.len()>=2)
            .map(|n| TunnelInfo { room: n.room.clone(), wings: n.wings.clone(), count: n.count })
            .collect();
        top.sort_by(|a,b| b.wings.len().cmp(&a.wings.len()).then(b.count.cmp(&a.count)));
        top.truncate(10);
        GraphStats { total_rooms: self.nodes.len(), tunnel_rooms, total_edges, rooms_per_wing: rpw, top_tunnels: top }
    }
}
