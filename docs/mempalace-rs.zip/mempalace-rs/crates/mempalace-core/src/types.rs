use std::collections::HashMap;
use chrono::{DateTime, Utc};
use serde::{Deserialize, Serialize};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Drawer {
    pub id: String,
    pub wing: String,
    pub room: String,
    #[serde(default)] pub hall: String,
    pub content: String,
    #[serde(default)] pub source_file: String,
    #[serde(default)] pub chunk_index: i64,
    #[serde(default = "default_added_by")] pub added_by: String,
    pub filed_at: DateTime<Utc>,
    #[serde(default = "default_importance")] pub importance: f32,
}
fn default_added_by() -> String { "mempalace".into() }
fn default_importance() -> f32 { 3.0 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DrawerInput {
    pub wing: String,
    pub room: String,
    #[serde(default)] pub hall: String,
    pub content: String,
    #[serde(default)] pub source_file: String,
    #[serde(default)] pub chunk_index: i64,
    #[serde(default = "default_added_by")] pub added_by: String,
    #[serde(default = "default_importance")] pub importance: f32,
}

#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct SearchFilter {
    pub wing: Option<String>,
    pub room: Option<String>,
    pub hall: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SearchResult {
    pub drawer: Drawer,
    /// Final score after reranking (may differ from raw cosine similarity).
    pub score: f32,
    /// 1-based rank in the final result set.
    pub rank: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Entity {
    pub id: String,
    pub name: String,
    #[serde(rename = "type")] pub entity_type: String,
    pub properties: HashMap<String, serde_json::Value>,
    pub created_at: DateTime<Utc>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TripleInput {
    pub subject: String,
    pub predicate: String,
    pub object: String,
    pub valid_from: Option<String>,
    pub valid_to: Option<String>,
    #[serde(default = "default_confidence")] pub confidence: f64,
    pub source_closet: Option<String>,
    pub source_file: Option<String>,
}
fn default_confidence() -> f64 { 1.0 }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ResolvedTriple {
    pub direction: String,
    pub subject: String,
    pub predicate: String,
    pub object: String,
    pub valid_from: Option<String>,
    pub valid_to: Option<String>,
    pub confidence: f64,
    pub source_closet: Option<String>,
    pub current: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomNode {
    pub room: String,
    pub wings: Vec<String>,
    pub halls: Vec<String>,
    pub count: usize,
    pub recent_dates: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TraversalHop {
    pub room: String,
    pub wings: Vec<String>,
    pub halls: Vec<String>,
    pub count: usize,
    pub hop: usize,
    #[serde(skip_serializing_if = "Option::is_none")]
    pub connected_via: Option<Vec<String>>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerStatus {
    pub palace_path: String,
    pub l0_identity: L0Status,
    pub l1_essential: LayerDesc,
    pub l2_on_demand: LayerDesc,
    pub l3_deep_search: LayerDesc,
    pub total_drawers: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct L0Status { pub path: String, pub exists: bool, pub tokens_estimate: usize }

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LayerDesc { pub description: String }

#[derive(Debug, Clone)]
pub struct Chunk {
    pub content: String,
    pub chunk_index: usize,
    pub memory_type: Option<String>,
}
