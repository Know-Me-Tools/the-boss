use std::collections::HashMap;
use std::path::{Path, PathBuf};

use serde::{Deserialize, Serialize};
use tracing::warn;

use crate::error::{MempalaceError, Result};

pub const DEFAULT_COLLECTION_NAME: &str = "mempalace_drawers";
pub const DEFAULT_EMBEDDING_MODEL: &str = "all-MiniLM-L6-v2";
pub const EMBEDDING_DIM: usize = 384;
/// How many more candidates to fetch than the final `limit` for reranking.
pub const DEFAULT_CANDIDATE_FACTOR: usize = 5;

pub fn default_palace_path() -> PathBuf {
    dirs::home_dir().unwrap_or_else(|| PathBuf::from(".")).join(".mempalace").join("palace")
}
pub fn default_config_dir() -> PathBuf {
    dirs::home_dir().unwrap_or_else(|| PathBuf::from(".")).join(".mempalace")
}
pub fn default_identity_path() -> PathBuf { default_config_dir().join("identity.txt") }
pub fn default_kg_path() -> PathBuf { default_config_dir().join("knowledge_graph.sqlite3") }

pub fn default_topic_wings() -> Vec<String> {
    ["emotions","consciousness","memory","technical","identity","family","creative"]
        .iter().map(|s| s.to_string()).collect()
}
pub fn default_hall_keywords() -> HashMap<String, Vec<String>> {
    let mut m = HashMap::new();
    m.insert("emotions".into(),      vec!["scared","afraid","worried","happy","sad","love","hate","feel","cry","tears"].iter().map(|s|s.to_string()).collect());
    m.insert("consciousness".into(), vec!["consciousness","conscious","aware","real","genuine","soul","exist","alive"].iter().map(|s|s.to_string()).collect());
    m.insert("memory".into(),        vec!["memory","remember","forget","recall","archive","palace","store"].iter().map(|s|s.to_string()).collect());
    m.insert("technical".into(),     vec!["code","rust","python","script","bug","error","function","api","database","server"].iter().map(|s|s.to_string()).collect());
    m.insert("identity".into(),      vec!["identity","name","who am i","persona","self"].iter().map(|s|s.to_string()).collect());
    m.insert("family".into(),        vec!["family","kids","children","daughter","son","parent","mother","father"].iter().map(|s|s.to_string()).collect());
    m.insert("creative".into(),      vec!["game","gameplay","player","app","design","art","music","story"].iter().map(|s|s.to_string()).collect());
    m
}

// ── Reranker configuration ────────────────────────────────────────────────────

/// Which reranker strategy to use.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(tag = "type", rename_all = "snake_case")]
pub enum RerankerConfig {
    /// Default: sort by initial cosine-similarity score — zero extra latency.
    CosineSimilarity,

    /// Cross-encoder via an OpenAI-compatible `/v1/rerank` endpoint
    /// (Cohere, Jina, Mixedbread, liter-llm, etc.).
    CrossEncoder {
        url: String,
        #[serde(default)]
        api_key: Option<String>,
        model: String,
    },

    /// Reciprocal Rank Fusion — combine multiple ranked lists.
    /// `k` is the RRF constant (typically 60.0).
    Rrf {
        #[serde(default = "default_rrf_k")]
        k: f32,
    },

    /// Weighted blend of two rerankers.
    Weighted {
        primary:        Box<RerankerConfig>,
        secondary:      Box<RerankerConfig>,
        /// Weight for `primary` (0.0–1.0); secondary gets `1 - weight`.
        #[serde(default = "default_weight")]
        primary_weight: f32,
    },
}

fn default_rrf_k() -> f32 { 60.0 }
fn default_weight() -> f32 { 0.7 }

impl Default for RerankerConfig {
    fn default() -> Self { Self::CosineSimilarity }
}

// ── Project-level config (mempalace.yaml) ─────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RoomConfig {
    pub name:        String,
    #[serde(default)] pub description: String,
    #[serde(default)] pub keywords:    Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectConfig {
    pub wing: String,
    #[serde(default)] pub rooms:       Vec<RoomConfig>,
    #[serde(default)] pub description: String,
}

impl ProjectConfig {
    pub fn load(project_dir: &Path) -> Result<Self> {
        let p1 = project_dir.join("mempalace.yaml");
        let p2 = project_dir.join("mempal.yaml");
        let path = if p1.exists() { p1 } else if p2.exists() { p2 } else {
            return Err(MempalaceError::config(format!(
                "No mempalace.yaml in {}. Run: mempalace init <dir>",
                project_dir.display())));
        };
        let s = std::fs::read_to_string(&path)?;
        Ok(serde_yaml::from_str(&s)?)
    }
}

// ── Global config (~/.mempalace/config.json) ──────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MempalaceConfig {
    #[serde(default = "default_palace_path")]
    pub palace_path: PathBuf,

    #[serde(default = "default_collection_name_str")]
    pub collection_name: String,

    #[serde(default = "default_topic_wings")]
    pub topic_wings: Vec<String>,

    #[serde(default = "default_hall_keywords")]
    pub hall_keywords: HashMap<String, Vec<String>>,

    #[serde(default)]
    pub people_map: HashMap<String, String>,

    // ── Embedding ─────────────────────────────────────────────────────────────
    /// If set, calls a remote OpenAI-compatible /v1/embeddings endpoint.
    /// If None, local fastembed is used (no API key, no network).
    #[serde(default)]
    pub embedding_api_url: Option<String>,
    #[serde(default)]
    pub embedding_api_key: Option<String>,
    #[serde(default = "default_embedding_model")]
    pub embedding_model: String,

    // ── Reranker ─────────────────────────────────────────────────────────────
    /// Reranking strategy applied after the first-stage embedding retrieval.
    #[serde(default)]
    pub reranker: RerankerConfig,

    /// Stage-1 over-fetch factor.
    /// If `limit=5` and `candidate_factor=5`, stage 1 fetches 25 candidates
    /// before handing them to the reranker which trims back to 5.
    #[serde(default = "default_candidate_factor")]
    pub candidate_factor: usize,
}

fn default_collection_name_str() -> String { DEFAULT_COLLECTION_NAME.into() }
fn default_embedding_model()     -> String { DEFAULT_EMBEDDING_MODEL.into() }
fn default_candidate_factor()    -> usize  { DEFAULT_CANDIDATE_FACTOR }

impl Default for MempalaceConfig {
    fn default() -> Self {
        Self {
            palace_path:      default_palace_path(),
            collection_name:  DEFAULT_COLLECTION_NAME.into(),
            topic_wings:      default_topic_wings(),
            hall_keywords:    default_hall_keywords(),
            people_map:       HashMap::new(),
            embedding_api_url: None,
            embedding_api_key: None,
            embedding_model:  DEFAULT_EMBEDDING_MODEL.into(),
            reranker:         RerankerConfig::default(),
            candidate_factor: DEFAULT_CANDIDATE_FACTOR,
        }
    }
}

impl MempalaceConfig {
    pub fn load() -> Self { Self::load_from(&default_config_dir()) }

    pub fn load_from(config_dir: &Path) -> Self {
        let mut cfg = Self::default();

        if let Ok(v) = std::env::var("MEMPALACE_PALACE_PATH")
            .or_else(|_| std::env::var("MEMPAL_PALACE_PATH")) {
            cfg.palace_path = PathBuf::from(v);
        }
        if let Ok(v) = std::env::var("MEMPALACE_EMBEDDING_API_URL") { cfg.embedding_api_url = Some(v); }
        if let Ok(v) = std::env::var("MEMPALACE_EMBEDDING_API_KEY") { cfg.embedding_api_key = Some(v); }

        let config_file = config_dir.join("config.json");
        if config_file.exists() {
            match std::fs::read_to_string(&config_file)
                .ok()
                .and_then(|s| serde_json::from_str::<MempalaceConfig>(&s).ok())
            {
                Some(fc) => {
                    if std::env::var("MEMPALACE_PALACE_PATH").is_err() { cfg.palace_path = fc.palace_path; }
                    cfg.collection_name  = fc.collection_name;
                    cfg.topic_wings      = fc.topic_wings;
                    cfg.hall_keywords    = fc.hall_keywords;
                    cfg.people_map       = fc.people_map;
                    cfg.embedding_model  = fc.embedding_model;
                    cfg.reranker         = fc.reranker;
                    cfg.candidate_factor = fc.candidate_factor;
                    if fc.embedding_api_url.is_some() && cfg.embedding_api_url.is_none() {
                        cfg.embedding_api_url = fc.embedding_api_url;
                        cfg.embedding_api_key = fc.embedding_api_key;
                    }
                }
                None => warn!("Failed to parse ~/.mempalace/config.json"),
            }
        }

        let people_map_file = config_dir.join("people_map.json");
        if people_map_file.exists() {
            if let Ok(s) = std::fs::read_to_string(&people_map_file) {
                if let Ok(m) = serde_json::from_str(&s) { cfg.people_map = m; }
            }
        }

        cfg
    }

    pub fn init(&self) -> Result<PathBuf> {
        let dir = default_config_dir();
        std::fs::create_dir_all(&dir)?;
        let f = dir.join("config.json");
        if !f.exists() {
            let j = serde_json::to_string_pretty(self).map_err(|e| MempalaceError::Config(e.to_string()))?;
            std::fs::write(&f, j)?;
        }
        Ok(f)
    }

    pub fn save_people_map(&self, map: &HashMap<String, String>) -> Result<PathBuf> {
        let dir = default_config_dir();
        std::fs::create_dir_all(&dir)?;
        let f = dir.join("people_map.json");
        let j = serde_json::to_string_pretty(map).map_err(|e| MempalaceError::Config(e.to_string()))?;
        std::fs::write(&f, j)?;
        Ok(f)
    }
}

impl MempalaceConfig {
    /// Human-readable reranker name for status display.
    pub fn reranker_name(&self) -> &'static str {
        match &self.reranker {
            RerankerConfig::CosineSimilarity  => "cosine-similarity",
            RerankerConfig::CrossEncoder {..} => "cross-encoder",
            RerankerConfig::Rrf {..}          => "rrf",
            RerankerConfig::Weighted {..}     => "weighted",
        }
    }
}
