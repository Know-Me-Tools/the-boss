use thiserror::Error;

#[derive(Debug, Error)]
pub enum MempalaceError {
    #[error("Palace not found at {path}: run `mempalace init <dir>` first")]
    PalaceNotFound { path: String },
    #[error("No drawers found — run `mempalace mine <dir>` to populate the palace")]
    CollectionNotFound,
    #[error("Database error: {0}")]
    Database(#[from] sqlx::Error),
    #[error("Migration error: {0}")]
    Migration(#[from] sqlx::migrate::MigrateError),
    #[error("Embedding error: {0}")]
    Embedding(String),
    #[error("Reranker error: {0}")]
    Reranker(String),
    #[error("IO error: {0}")]
    Io(#[from] std::io::Error),
    #[error("JSON error: {0}")]
    Json(#[from] serde_json::Error),
    #[error("YAML error: {0}")]
    Yaml(#[from] serde_yaml::Error),
    #[error("Configuration error: {0}")]
    Config(String),
    #[error("Duplicate drawer (similarity {similarity:.3})")]
    Duplicate { similarity: f32 },
    #[error("Drawer not found: {id}")]
    DrawerNotFound { id: String },
    #[error("{0}")]
    Other(String),
}

impl MempalaceError {
    #[cold] #[inline(never)]
    pub fn palace_not_found(p: impl Into<String>) -> Self { Self::PalaceNotFound { path: p.into() } }
    #[cold] #[inline(never)]
    pub fn embedding(m: impl Into<String>) -> Self { Self::Embedding(m.into()) }
    #[cold] #[inline(never)]
    pub fn reranker(m: impl Into<String>) -> Self { Self::Reranker(m.into()) }
    #[cold] #[inline(never)]
    pub fn config(m: impl Into<String>) -> Self { Self::Config(m.into()) }
    #[cold] #[inline(never)]
    pub fn other(m: impl Into<String>) -> Self { Self::Other(m.into()) }
}

pub type Result<T> = std::result::Result<T, MempalaceError>;
