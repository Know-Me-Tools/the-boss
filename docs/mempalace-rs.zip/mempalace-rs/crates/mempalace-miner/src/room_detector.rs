use std::path::Path;
use std::collections::HashMap;
use mempalace_core::RoomConfig;

pub fn detect_room(filepath: &Path, content: &str, rooms: &[RoomConfig], project_path: &Path) -> String {
    if rooms.is_empty() { return "general".into(); }
    let rel = filepath.strip_prefix(project_path).unwrap_or(filepath)
        .to_string_lossy().to_lowercase().replace('\\', "/");
    let fname = filepath.file_stem().unwrap_or_default().to_string_lossy().to_lowercase();
    let lower = content[..content.len().min(2000)].to_lowercase();
    let parts: Vec<&str> = rel.splitn(99, '/').collect();
    if parts.len() > 1 {
        for part in &parts[..parts.len()-1] {
            for r in rooms { let rn = r.name.to_lowercase(); if rn.contains(part) || part.contains(&*rn) { return r.name.clone(); } }
        }
    }
    for r in rooms { let rn = r.name.to_lowercase(); if rn.contains(&*fname) || fname.contains(&*rn) { return r.name.clone(); } }
    let mut scores: HashMap<&str, usize> = HashMap::new();
    for r in rooms {
        let kws: Vec<String> = r.keywords.iter().chain(std::iter::once(&r.name)).map(|k| k.to_lowercase()).collect();
        let score: usize = kws.iter().map(|k| lower.matches(k.as_str()).count()).sum();
        if score > 0 { *scores.entry(r.name.as_str()).or_default() += score; }
    }
    scores.iter().max_by_key(|(_, v)| *v).map(|(k, _)| k.to_string()).unwrap_or_else(|| "general".into())
}
