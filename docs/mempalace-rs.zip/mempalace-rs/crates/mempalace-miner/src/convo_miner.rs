use std::collections::HashMap;
use std::path::{Path, PathBuf};
use tracing::{info, warn};
use walkdir::WalkDir;
use mempalace_core::{DrawerInput, MempalaceError, Result};
use mempalace_store::DrawerStore;
use mempalace_normalize::{chunk_exchanges, detect_convo_room, normalize_file};

const CONVO_EXT:  &[&str] = &["txt","md","json","jsonl"];
const SKIP_DIRS:  &[&str] = &[".git","node_modules","__pycache__",".venv",".mempalace","target"];

#[derive(Debug,Clone,Default)]
pub struct ConvoMineOptions { pub wing: Option<String>, pub agent: String, pub limit: usize, pub dry_run: bool }
#[derive(Debug,Default)]
pub struct ConvoMineResult { pub total_files: usize, pub files_processed: usize, pub files_skipped: usize, pub drawers_filed: usize, pub by_room: HashMap<String,usize> }

pub fn scan_convos(dir: &Path) -> Vec<PathBuf> {
    WalkDir::new(dir).follow_links(false).into_iter()
        .filter_entry(|e| !SKIP_DIRS.contains(&e.file_name().to_string_lossy().as_ref()))
        .filter_map(|e| e.ok()).filter(|e| e.file_type().is_file())
        .filter(|e| e.path().extension().and_then(|x| x.to_str()).map(|ext| CONVO_EXT.contains(&ext.to_lowercase().as_str())).unwrap_or(false))
        .map(|e| e.into_path()).collect()
}

pub async fn mine_convos(dir: &Path, store: &DrawerStore, mut opts: ConvoMineOptions) -> Result<ConvoMineResult> {
    let wing = opts.wing.take().unwrap_or_else(|| dir.file_name().unwrap_or_default().to_string_lossy().to_lowercase().replace([' ','-'],'_').replace('-','_'));
    let mut files = scan_convos(dir);
    if opts.limit > 0 { files.truncate(opts.limit); }
    let mut res = ConvoMineResult { total_files: files.len(), ..Default::default() };
    info!("Mine convos — wing={wing} files={} dry_run={}", files.len(), opts.dry_run);
    for fp in &files {
        let src = fp.to_string_lossy().into_owned();
        if !opts.dry_run && store.file_already_mined(&src).await? { res.files_skipped += 1; continue; }
        let content = match normalize_file(fp) { Ok(c) => c, Err(e) => { warn!("Skip {}: {e}", fp.display()); continue; } };
        if content.trim().len() < 30 { continue; }
        let chunks = chunk_exchanges(&content);
        if chunks.is_empty() { continue; }
        let room = detect_convo_room(&content);
        if opts.dry_run {
            println!("  [DRY] {} → room:{room} ({} chunks)", fp.file_name().unwrap_or_default().to_string_lossy(), chunks.len());
            res.drawers_filed += chunks.len(); *res.by_room.entry(room).or_default() += 1; res.files_processed += 1; continue;
        }
        let mut added = 0usize;
        for c in &chunks {
            match store.add(DrawerInput { wing: wing.clone(), room: room.clone(), hall: String::new(), content: c.content.clone(), source_file: src.clone(), chunk_index: c.chunk_index as i64, added_by: opts.agent.clone(), importance: 3.0 }).await {
                Ok(_) => added += 1,
                Err(MempalaceError::Database(e)) if e.to_string().contains("UNIQUE") => {}
                Err(e) => return Err(e),
            }
        }
        res.drawers_filed += added; res.files_processed += 1; *res.by_room.entry(room).or_default() += 1;
    }
    Ok(res)
}
