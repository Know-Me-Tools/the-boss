use std::collections::HashMap;
use std::path::{Path, PathBuf};
use tracing::{info, warn};
use walkdir::WalkDir;
use mempalace_core::{DrawerInput, MempalaceError, ProjectConfig, Result};
use mempalace_store::DrawerStore;
use crate::chunker::chunk_text;
use crate::room_detector::detect_room;

const READABLE_EXT: &[&str] = &["txt","md","py","js","ts","jsx","tsx","json","yaml","yml","html","css","java","go","rs","rb","sh","csv","sql","toml","c","cpp","h","cs"];
const SKIP_DIRS:  &[&str] = &[".git","node_modules","__pycache__",".venv","venv","dist","build",".next",".mempalace","target"];
const SKIP_FILES: &[&str] = &["mempalace.yaml","mempalace.yml","mempal.yaml",".gitignore","package-lock.json","Cargo.lock"];

#[derive(Debug,Clone,Default)]
pub struct MineOptions { pub wing_override: Option<String>, pub agent: String, pub limit: usize, pub dry_run: bool }

#[derive(Debug,Default)]
pub struct MineResult { pub total_files: usize, pub files_processed: usize, pub files_skipped: usize, pub drawers_filed: usize, pub by_room: HashMap<String,usize> }

pub fn scan_project(dir: &Path) -> Vec<PathBuf> {
    WalkDir::new(dir).follow_links(false).into_iter()
        .filter_entry(|e| !SKIP_DIRS.contains(&e.file_name().to_string_lossy().as_ref()))
        .filter_map(|e| e.ok())
        .filter(|e| e.file_type().is_file())
        .filter(|e| {
            let name = e.file_name().to_string_lossy();
            if SKIP_FILES.contains(&name.as_ref()) { return false; }
            e.path().extension().and_then(|x| x.to_str()).map(|ext| READABLE_EXT.contains(&ext.to_lowercase().as_str())).unwrap_or(false)
        })
        .map(|e| e.into_path()).collect()
}

pub async fn mine(project_dir: &Path, store: &DrawerStore, mut opts: MineOptions) -> Result<MineResult> {
    let config = ProjectConfig::load(project_dir)?;
    let wing   = opts.wing_override.take().unwrap_or(config.wing.clone());
    let rooms  = config.rooms.clone();
    let mut files = scan_project(project_dir);
    if opts.limit > 0 { files.truncate(opts.limit); }
    let mut res = MineResult { total_files: files.len(), ..Default::default() };
    info!("Mine {} — wing={wing} files={} dry_run={}", project_dir.display(), files.len(), opts.dry_run);
    for filepath in &files {
        let src = filepath.to_string_lossy().into_owned();
        if !opts.dry_run && store.file_already_mined(&src).await? { res.files_skipped += 1; continue; }
        let content = match std::fs::read_to_string(filepath) { Ok(c) => c.trim().to_string(), Err(e) => { warn!("Skip {}: {e}", filepath.display()); continue; } };
        if content.len() < crate::chunker::MIN_CHUNK_SIZE { continue; }
        let room   = detect_room(filepath, &content, &rooms, project_dir);
        let chunks = chunk_text(&content);
        if opts.dry_run {
            println!("  [DRY] {} → room:{room} ({} chunks)", filepath.file_name().unwrap_or_default().to_string_lossy(), chunks.len());
            res.drawers_filed += chunks.len(); *res.by_room.entry(room).or_default() += 1; res.files_processed += 1; continue;
        }
        let mut added = 0usize;
        for c in &chunks {
            match store.add(DrawerInput { wing: wing.clone(), room: room.clone(), hall: String::new(), content: c.content.clone(), source_file: src.clone(), chunk_index: c.chunk_index as i64, added_by: opts.agent.clone(), importance: 3.0 }).await {
                Ok(_) => added += 1,
                Err(MempalaceError::Database(e)) if e.to_string().contains("UNIQUE") => {}
                Err(e) => return Err(e),
            }
        }
        res.drawers_filed += added; res.files_processed += 1; *res.by_room.entry(room).or_default() += 1;
    }
    Ok(res)
}
