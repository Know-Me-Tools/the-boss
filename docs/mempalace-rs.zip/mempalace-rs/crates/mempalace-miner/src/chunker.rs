use mempalace_core::Chunk;
pub const CHUNK_SIZE: usize = 800;
pub const CHUNK_OVERLAP: usize = 100;
pub const MIN_CHUNK_SIZE: usize = 50;

pub fn chunk_text(content: &str) -> Vec<Chunk> {
    let content = content.trim();
    if content.is_empty() { return Vec::new(); }
    let mut chunks = Vec::new();
    let len = content.len();
    let mut start = 0;
    while start < len {
        let end = (start + CHUNK_SIZE).min(len);
        let end = if end < len {
            rfind(content, "\n\n", start, end)
                .filter(|&p| p > start + CHUNK_SIZE/2)
                .or_else(|| rfind(content, "\n", start, end).filter(|&p| p > start + CHUNK_SIZE/2))
                .unwrap_or(end)
        } else { end };
        let chunk = content[start..end].trim();
        if chunk.len() >= MIN_CHUNK_SIZE {
            let idx = chunks.len();
            chunks.push(Chunk { content: chunk.to_string(), chunk_index: idx, memory_type: None });
        }
        start = if end < len { end.saturating_sub(CHUNK_OVERLAP) } else { end };
    }
    chunks
}
fn rfind(s: &str, needle: &str, from: usize, to: usize) -> Option<usize> {
    s[from..to].rfind(needle).map(|p| from + p)
}
