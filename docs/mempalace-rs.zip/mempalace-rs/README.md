# mempalace-rs

A Rust port of [MemPalace](https://github.com/milla-jovovich/mempalace) — give your AI a memory. No API key required.

## Architecture

```
mempalace-core      — Config, types, errors, RerankerConfig
mempalace-store     — SQLite vector store, KnowledgeGraph, Embedder, Reranker
mempalace-layers    — 4-layer memory stack (L0–L3 + MemoryStack)
mempalace-miner     — File + conversation mining
mempalace-normalize — Claude / ChatGPT / Slack export normaliser
mempalace-graph     — Palace graph traversal
mempalace-mcp       — JSON-RPC stdio MCP server (20+ tools)
mempalace-cli       — `mempalace` CLI binary
```

## Quick start

```bash
cargo build --release

# Initialise palace config
mempalace init

# Mine a project
mempalace mine ~/my-project

# Search
mempalace search "chromadb setup"

# Start MCP server (for Claude Code)
mempalace mcp
```

## Two-stage search

Stage 1: cosine similarity over all embeddings → top `limit × candidate_factor` candidates  
Stage 2: reranker refines to final `limit`

Configured in `~/.mempalace/config.json`:

```json
{
  "reranker": { "type": "cosine_similarity" },
  "candidate_factor": 5
}
```

To use a cross-encoder (e.g. liter-llm `/v1/rerank`):

```json
{
  "reranker": {
    "type": "cross_encoder",
    "url": "http://localhost:4000/v1/rerank",
    "model": "rerank-english-v3.0"
  },
  "candidate_factor": 10
}
```

## MCP tools

`mempalace_status`, `mempalace_search`, `mempalace_add_drawer`, `mempalace_delete_drawer`,  
`mempalace_kg_query`, `mempalace_kg_add`, `mempalace_kg_invalidate`, `mempalace_kg_timeline`, `mempalace_kg_stats`,  
`mempalace_traverse`, `mempalace_find_tunnels`, `mempalace_graph_stats`,  
`mempalace_wake_up`, `mempalace_recall`, `mempalace_diary_write`, `mempalace_diary_read`, and more.
